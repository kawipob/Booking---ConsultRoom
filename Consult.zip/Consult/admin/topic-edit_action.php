<?php
    session_start();
    include 'db_connect.php';
    $conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);
    
    // Check connection
    if (!$conn) {
        die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
    }

    $topic_id = $_POST["topic_id"];
    $t_topic = $_POST['t_topic'];
    $t_detail = $_POST['t_detail'];
    $refer = $_POST['refer'];   
    $deleted_id = $_POST['deleted_id'];

    // Prepared statement to prevent SQL injection
    $sql = "UPDATE topic SET t_topic=?, t_detail=?, refer=?, deleted_id=? WHERE topic_id=?";
    $stmt = mysqli_prepare($conn, $sql);

    // Check if the prepare() call succeeded
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'sssii', $t_topic, $t_detail, $refer, $deleted_id, $topic_id);
        $result = mysqli_stmt_execute($stmt);

        if ($result) {
            echo '<script>alert("แก้ไขข้อมูลเรียบร้อยแล้ว");window.location="page-topic.php";</script>';
            exit();
        } else {
            echo "เกิดข้อผิดพลาดในการอัปเดตข้อมูล: " . mysqli_stmt_error($stmt);
        }
    } else {
        echo "เกิดข้อผิดพลาดในการเตรียมคำสั่ง SQL: " . mysqli_error($conn);
    }

    mysqli_stmt_close($stmt);
    mysqli_close($conn);
?>
