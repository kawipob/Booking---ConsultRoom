<?php
session_start();
include 'db_connect.php';
$conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);

// เช็คการเชื่อมต่อ
if (!$conn) {
    die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
}


if (!isset($_SESSION['user_login'])) { // ถ้าไม่ได้เข้าระบบอยู่
    header("location: \Consult\login.php"); // redirect ไปยังหน้า login.php
    exit;
}

$user = $_SESSION['user_login'];
// กลับมาแก้ หลังจากเปลี่ยนที่เก็บข้อมูล
if ($user['level'] != 'admin') {
    echo '<script>alert("สำหรับผู้ดูแลระบบเท่านั้น");window.location="index.php";</script>';
    exit;
}
		// การออกจากระบบ
	if (isset($_GET['logout'])) {
		// ลบข้อมูล session ทั้งหมด
		session_unset();
		// ทำลาย session
		session_destroy();
		// Redirect ไปยังหน้าเข้าสู่ระบบหรือหน้าที่ต้องการ
		header("location: \Consult\login.php"); // เปลี่ยนเส้นทางไปยังหน้าที่ต้องการหลังจากออกจากระบบ
		exit;
	}
?>

<!DOCTYPE html>
<html>
<head>
    <!-- iCons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- ICON LOGO WEB -->
    <link rel="icon" type="image/นามสกุลไฟล์" href="image/satit student.png" />
    <title>แอดมิน | หน้าแดชบอร์ด</title>
    <!-- ใส่ CSS -->
    <link rel="stylesheet" href="css/page-teacher-add.css">
</head>
<body>
<header>
    <h2>เพิ่ม อาจารย์ที่ปรึกษา</h2>
    <h4>ยินดีต้อนรับ <?php echo $user['fullname']; ?></h4>
</header>

<div class="sidebar">
    <h2>DMSU Consult Room</h2>
    <a href="admin.php"><i class="fas fa-home"></i> แดชบอร์ด</a>
    <a href="page-user.php"><i class="fas fa-users"></i> จัดการ ผู้ใช้งานทั้งหมด</a>
    <a href="page-teacher.php"><i class="fas fa-chalkboard-teacher"></i> จัดการ อาจารย์ที่ปรึกษา</a>
    <a href="page-topic.php"><i class="fas fa-tasks"></i> จัดการ หัวข้อการปรึกษา</a>
    <a href="page-question.php"><i class="fas fa-clipboard-check"></i></i> จัดการ แบบทดสอบ</a>
    <a href="page-profile.php"><i class="fas fa-user"></i> โปรไฟล์</a>
    <a href="?logout=true"><i class="fas fa-sign-out-alt"></i> ออกจากระบบ</a>
</div>


<div class="content">
        <form action="teacher-add_action.php" method="POST" enctype="multipart/form-data">

            <label for="email">อีเมลล์ : </label><br>
            <input type="text" id="email" name="email" required><br><br>

            <label for="username">ชื่อบัญชีผู้ใช้งาน : </label><br>
            <input type="text" id="username" name="username" required><br><br>

            <label for="password">รหัสผ่าน :</label><br>
            <input type="password" id="password" name="password" required><br><br>

            <label for="fullname">ชื่อ - นามสกุล : </label><br>
            <input type="text" id="fullname" name="fullname" required><br><br>

            <label for="phone">เบอร์โทรศัพท์ : </label><br>
            <input type="text" id="phone" name="phone" required><br><br>

            <label for="structure">อาคาร : </label><br>
            <select id="structure" name="structure" required>
                <option value="1 ชั้น 1 ">1 ชั้น 1 </option>
                <option value="1 ชั้น 2 ">1 ชั้น 2 </option>
            </select><br><br>

            <label for="room">ห้อง : </label><br>
            <select id="room" name="room" required>
                <option value="กิจกรรมพัฒนาผู้เรียน (แนะเเนว) โต๊ะ 1">กิจกรรมพัฒนาผู้เรียน (แนะเเนว) โต๊ะ 1</option>
                <option value="กิจกรรมพัฒนาผู้เรียน (แนะเเนว) โต๊ะ 2">กิจกรรมพัฒนาผู้เรียน (แนะเเนว) โต๊ะ 2</option>
                <option value="กิจกรรมพัฒนาผู้เรียน (แนะเเนว) โต๊ะ 3">กิจกรรมพัฒนาผู้เรียน (แนะเเนว) โต๊ะ 3</option>
                <option value="ห้องปรึกษาปัญหา 1 ">ห้องพัฒนาสุขภาวะ 1 </option>
                <option value="ห้องปรึกษาปัญหา 1 ">ห้องพัฒนาสุขภาวะ 2 </option>
            </select><br><br>

            <label for="image">รูปภาพโปรไฟล์: </label><br>
            <input type="file" id="imgInput" name="image" accept="image/*"><br><br>
            <img loading="lazy" width="10%" id="previewImg" alt=""><br><br>

            <input type="submit" value="บันทึก"> <a href="page-teacher.php" class="back">ย้อนกลับ</a>
        
        </form>
        <br><br>
    </div>

    <script>
        let imgInput = document.getElementById('imgInput');
        let previewImg = document.getElementById('previewImg');

        imgInput.onchange = evt => {
            const [file] = imgInput.files;
                if (file) {
                    previewImg.src = URL.createObjectURL(file)
            }
        }

    </script>

</body>     
</html>
