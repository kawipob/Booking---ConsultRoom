<?php
session_start();
include 'db_connect.php';
$conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);

// เช็คการเชื่อมต่อ
if (!$conn) {
    die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
}

if (!isset($_SESSION['user_login'])) {
    header("location: \Consult\login.php");
    exit;
}

$user = $_SESSION['user_login'];
if ($user['level'] != 'admin') {
    echo '<script>alert("สำหรับผู้ดูแลระบบเท่านั้น");window.location="index.php";</script>';
    exit;
}

    $id = $_POST["id"];
    $fullname = $_POST['fullname'];
    $username = $_POST['username'];
    $password = $_POST['password'];

        // Prepared statement to prevent SQL injection
        $sql = "UPDATE admin SET fullname=?, username=?,  password=? WHERE id=?";
        $stmt = mysqli_prepare($conn, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'sssi', $fullname, $username, $password, $id);
        $result = mysqli_stmt_execute($stmt);
    
        if ($result) {
            echo '<script>alert("แก้ไขข้อมูลเรียบร้อยแล้ว");window.location="page-profile.php";</script>';
            exit();
        } else {
            echo "เกิดข้อผิดพลาดในการอัปเดตข้อมูล: " . mysqli_stmt_error($stmt);
        }
    } else {
        echo "เกิดข้อผิดพลาดในการเตรียมคำสั่ง SQL: " . mysqli_error($conn);
    }
    

    mysqli_stmt_close($stmt);
    mysqli_close($conn);


?>
