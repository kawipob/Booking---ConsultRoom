<?php
session_start();
include 'db_connect.php';
$conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);

if(isset($_GET['teacher_id'])) {
    $teacher_id = $_GET['teacher_id'];
    
    // Assuming $conn is your database connection
    $query = "UPDATE teacher SET deleted_id = 1 WHERE teacher_id = $teacher_id";
    
    if ($conn->query($query) === TRUE) {

        echo '<script>alert("ลบข้อมูลแบบ SoftDelete ");window.location="page-teacher.php";</script>';
        exit();
    } else {
        echo "Error updating record: " . $conn->error;
    }
} else {
    echo "Teacher ID not provided.";
}
?>