<?php
session_start();
include 'db_connect.php';
$conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);

// เช็คการเชื่อมต่อ
if (!$conn) {
    die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
}


if (!isset($_SESSION['user_login'])) { // ถ้าไม่ได้เข้าระบบอยู่
    header("location: \Consult\login.php"); // redirect ไปยังหน้า login.php
    exit;
}

$user = $_SESSION['user_login'];
if ($user['level'] != 'admin') {
    echo '<script>alert("สำหรับผู้ดูแลระบบเท่านั้น");window.location="index.php";</script>';
    exit;
}
		// การออกจากระบบ
	if (isset($_GET['logout'])) {
		// ลบข้อมูล session ทั้งหมด
		session_unset();
		// ทำลาย session
		session_destroy();
		// Redirect ไปยังหน้าเข้าสู่ระบบหรือหน้าที่ต้องการ
		header("location: \Consult\login.php"); // เปลี่ยนเส้นทางไปยังหน้าที่ต้องการหลังจากออกจากระบบ
		exit;
	}
    // คำสั่ง SQL เพื่อดึงข้อมูลจากตารางที่เก็บข้อมูลผู้ใช้งาน
$sql = "SELECT COUNT(*) as total_users FROM users WHERE role = 'user' ";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $totalUsers = $row["total_users"];
    }
} else {
    $totalUsers = 0;
}


// คำสั่ง SQL เพื่อดึงข้อมูลผู้ใช้ที่มี role เป็น 'user'
$query = "SELECT * FROM users WHERE role = 'user'";
$result = mysqli_query($conn, $query);

if (isset($_GET['search'])) {
    $search = $_GET['search'];
    // คำสั่ง SQL เพื่อค้นหาผู้ใช้งานที่ตรงกับชื่อที่ค้นหา
    $query = "SELECT * FROM users WHERE role = 'user' AND (username LIKE '%$search%' OR fullname LIKE '%$search%')";
    $result = mysqli_query($conn, $query);

    if (!$result) {
        die("เกิดข้อผิดพลาดในการค้นหา: " . mysqli_error($conn));
    }
}


?>

<!DOCTYPE html>
<html>
<head>
    <!-- iCons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- ICON LOGO WEB -->
    <link rel="icon" type="image/นามสกุลไฟล์" href="image/satit student.png" />
    <title>แอดมิน | หน้าแดชบอร์ด</title>
    <!-- ใส่ CSS -->
    <link rel="stylesheet" href="css/page-user.css">
</head>
<body>
<header>
    <h2>จัดการ ผู้ใช้งานทั้งหมด</h2>
    <h4>ยินดีต้อนรับ <?php echo $user['fullname']; ?></h4>
</header>

<div class="sidebar">
    <h2>DMSU Consult Room</h2>
    <a href="admin.php"><i class="fas fa-home"></i> แดชบอร์ด</a>
    <a href="page-user.php"><i class="fas fa-users"></i> จัดการ ผู้ใช้งานทั้งหมด</a>
    <a href="page-teacher.php"><i class="fas fa-chalkboard-teacher"></i> จัดการ อาจารย์ที่ปรึกษา</a>
    <a href="page-topic.php"><i class="fas fa-tasks"></i> จัดการ หัวข้อการปรึกษา</a>
    <a href="page-question.php"><i class="fas fa-clipboard-check"></i></i> จัดการ แบบทดสอบ</a>
    <a href="page-profile.php"><i class="fas fa-user"></i> โปรไฟล์</a>
    <a href="?logout=true"><i class="fas fa-sign-out-alt"></i> ออกจากระบบ</a>
</div>



<!-- เริ่มต้นส่วนของ content หลัก -->
<div class="content">

    <form method="GET" action="">
        <input type="text" name="search" placeholder="ค้นหาชื่อผู้ใช้งาน">
        <input type="submit" value="ค้นหา">
    </form>

    <br>
    <table border="1">
    <thead>
        <tr>
            <th>ลำดับ</th>
            <th>รหัสนักเรียน</th>
            <th>ชื่อผู้ใช้งาน</th>
            <th>เบอร์โทรติดต่อ</th>
            <th style="width: 3%;">แก้ไข</th>
            <th style="width: 3%;">ลบ</th>
        </tr>
    </thead>
    <tbody>
    <?php
        $count = 1;
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $count . "</td>";
                echo "<td>" . $row['username'] . "</td>";
                echo "<td>" . $row['fullname'] . "</td>";
                echo "<td>" . $row['phone'] . "</td>";
                echo "<td><a href='page-user-edit.php?id=" . $row['id'] . "' class='button-edit'><button><i class='fas fa-edit'></i></button></a></td>";
                echo "<td><a href='page-user-delete.php?id=" . $row['id'] . "' class='button-delete'><button><i class='fas fa-trash-alt'></i></button></a></td>";
                echo "</tr>";
                $count++;
            }
        } else {
            echo "<tr><td colspan='5'>ไม่พบผู้ใช้งานที่ค้นหา</td></tr>";
        }
    ?>
    </tbody>
</table>

</div>

</body>     
</html>
