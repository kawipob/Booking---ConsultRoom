<?php
session_start();
include 'db_connect.php';
$conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);

// เช็คการเชื่อมต่อ
if (!$conn) {
    die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
}


if (!isset($_SESSION['user_login'])) { // ถ้าไม่ได้เข้าระบบอยู่
    header("location: \Consult\login.php"); // redirect ไปยังหน้า login.php
    exit;
}

$user = $_SESSION['user_login'];
if ($user['level'] != 'admin') {
    echo '<script>alert("สำหรับผู้ดูแลระบบเท่านั้น");window.location="index.php";</script>';
    exit;
}
		// การออกจากระบบ
	if (isset($_GET['logout'])) {
		// ลบข้อมูล session ทั้งหมด
		session_unset();
		// ทำลาย session
		session_destroy();
		// Redirect ไปยังหน้าเข้าสู่ระบบหรือหน้าที่ต้องการ
		header("location: \Consult\login.php"); // เปลี่ยนเส้นทางไปยังหน้าที่ต้องการหลังจากออกจากระบบ
		exit;
	}
?>

<!DOCTYPE html>
<html>
<head>
    <!-- iCons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- ICON LOGO WEB -->
    <link rel="icon" type="image/นามสกุลไฟล์" href="image/satit student.png" />
    <title>แอดมิน | หน้าแดชบอร์ด</title>
    <!-- ใส่ CSS -->
    <link rel="stylesheet" href="css/page-profile.css">
    <style>
    </style>
</head>
<body>
<header>
    <h2>แก้ไข โปรไฟล์</h2>
    <h4>ยินดีต้อนรับ <?php echo $user['fullname']; ?></h4>
</header>

<div class="sidebar">
    <h2>DMSU Consult Room</h2>
    <a href="admin.php"><i class="fas fa-home"></i> แดชบอร์ด</a>
    <a href="page-user.php"><i class="fas fa-users"></i> จัดการ ผู้ใช้งานทั้งหมด</a>
    <a href="page-teacher.php"><i class="fas fa-chalkboard-teacher"></i> จัดการ อาจารย์ที่ปรึกษา</a>
    <a href="page-topic.php"><i class="fas fa-tasks"></i> จัดการ หัวข้อการปรึกษา</a>
    <a href="page-question.php"><i class="fas fa-clipboard-check"></i></i> จัดการ แบบทดสอบ</a>
    <a href="page-profile.php"><i class="fas fa-user"></i> โปรไฟล์</a>
    <a href="?logout=true"><i class="fas fa-sign-out-alt"></i> ออกจากระบบ</a>
</div>

<div class="content">
    <table border="1">
        <thead>
            <tr>
                <th style="width: 5%;">ลำดับ</th>
                <th style="width: 20%;">ชื่อ</th>
                <th style="width: 13%;">บัญชีผู้ใช้งาน</th>
                <th style="width: 5%;">แก้ไข</th>
                <th style="width: 5%;">ลบ</th>
            </tr>
        </thead>
        <tbody>
        <?php
            // ดึงข้อมูล admin ที่เข้าสู่ระบบอยู่
            $loggedInUserId = $user['id'];
            $query = "SELECT * FROM admin WHERE role = 'admin' AND id = $loggedInUserId";
            $result = $conn->query($query);
 
            if ($result->num_rows > 0) {
                $count = 1;
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $count . "</td>";
                    echo "<td>" . $row['fullname'] . "</td>";
                    echo "<td>" . $row['username'] . "</td>";
                    echo "<td><a href='page-profile-edit.php?id=" . $row['id'] . "' class='button-edit'><button><i class='fas fa-edit'></i></button></a></td>";
                    echo "<td><a href='teacher-softdelete_action.php?id=" . $row['id'] . "' class='button-delete'><button><i class='fas fa-trash-alt'></i></button></a></td>";
                    echo "</tr>";
                    $count++;
                }
            } else {
                echo "<tr><td colspan='5'>ไม่พบผู้ใช้งานที่ค้นหา</td></tr>";
            }
            ?>



        </tbody>
    </table>
</div>
</body>     
</html>
