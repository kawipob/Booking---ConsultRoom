<?php
    $serverName = "localhost";
    $userName = "root";
    $userPassword = "";
    $dbName = "php_login";
    $conn = mysqli_connect($serverName,$userName,$userPassword,$dbName);  
 ?>
