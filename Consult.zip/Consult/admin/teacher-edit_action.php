<?php
session_start();
include 'db_connect.php';
$conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);

if (!$conn) {
    die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
}

$teacher_id = $_POST['teacher_id'];
$email = $_POST['email'];
$username = $_POST['username'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Using bcrypt for password hashing
$fullname = $_POST['fullname'];
$phone = $_POST['phone'];
$structure = $_POST['structure'];
$room = $_POST['room'];

if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
    $image = $_FILES['image'];

    if ($image['size'] > 0) {
        $allow = array('jpg', 'jpeg', 'png');
        $extension = pathinfo($image['name'], PATHINFO_EXTENSION);
        $fileActExt = strtolower($extension);

        if (!in_array($fileActExt, $allow)) {
            echo "ไฟล์ที่อัปโหลดไม่รองรับ โปรดใช้ไฟล์รูปภาพเฉพาะนามสกุล jpg, jpeg, png";
            exit();
        }

        $fileNew = uniqid() . "." . $fileActExt;
        $filePath = 'uploads/' . $fileNew;

        // Move uploaded file to the server
        if (move_uploaded_file($image['tmp_name'], $filePath)) {
            $sql = "UPDATE teacher SET email=?, username=?, password=?, fullname=?, phone=?, structure=?, room=?, image=? WHERE teacher_id=?";
            $stmt = mysqli_prepare($conn, $sql);

            if ($stmt) {
                mysqli_stmt_bind_param($stmt, 'ssssssssi', $email, $username, $password, $fullname, $phone, $structure, $room, $fileNew, $teacher_id);

                $result = mysqli_stmt_execute($stmt);

                if ($result) {
                    echo '<script>alert("แก้ไขข้อมูลเรียบร้อยแล้ว");window.location="page-teacher.php";</script>';
                    exit();
                } else {
                    echo "เกิดข้อผิดพลาดในการอัปเดตข้อมูล: " . mysqli_stmt_error($stmt);
                }
            } else {
                echo "เกิดข้อผิดพลาดในการเตรียมคำสั่ง SQL: " . mysqli_error($conn);
            }

            mysqli_stmt_close($stmt);
        } else {
            echo "มีปัญหาในการอัปโหลดไฟล์";
        }
    } else {
        echo "ขนาดไฟล์ที่อัปโหลดเป็นศูนย์หรือไฟล์ว่าง";
    }
} else {
    // ไม่มีไฟล์ที่ถูกอัปโหลดหรือเกิดข้อผิดพลาดในการอัปโหลด
    // ในที่นี้คุณสามารถทำการอัปเดตข้อมูลโดยไม่ต้องการไฟล์รูปภาพ

    $sql = "UPDATE teacher SET email=?, username=?, password=?, fullname=?, phone=?, structure=?, room=? WHERE teacher_id=?";
    $stmt = mysqli_prepare($conn, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'sssssssi', $email, $username, $password, $fullname, $phone, $structure, $room, $teacher_id);

        $result = mysqli_stmt_execute($stmt);

        if ($result) {
            echo '<script>alert("แก้ไขข้อมูลเรียบร้อยแล้ว");window.location="page-teacher.php";</script>';
            exit();
        } else {
            echo "เกิดข้อผิดพลาดในการอัปเดตข้อมูล: " . mysqli_stmt_error($stmt);
        }
    } else {
        echo "เกิดข้อผิดพลาดในการเตรียมคำสั่ง SQL: " . mysqli_error($conn);
    }

    mysqli_stmt_close($stmt);
}

mysqli_close($conn);
?>
