<?php
session_start();
include 'db_connect.php';
$conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);

// เช็คการเชื่อมต่อ
if (!$conn) {
    die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
}

if (!isset($_SESSION['user_login'])) { // ถ้าไม่ได้เข้าระบบอยู่
    header("location: \Consult\login.php"); // redirect ไปยังหน้า login.php
    exit;
}

$user = $_SESSION['user_login'];
// กลับมาแก้ หลังจากเปลี่ยนที่เก็บข้อมูล
if ($user['level'] != 'admin') {
    echo '<script>alert("สำหรับผู้ดูแลระบบเท่านั้น");window.location="index.php";</script>';
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // ดึงข้อมูลจากฟอร์ม
    $t_topic = $_POST['t_topic'];
    $t_detail = $_POST['t_detail'];
    $refer = $_POST['refer'];

    $insert_query = "INSERT INTO topic (t_topic, t_detail, refer, deleted_id) VALUES ('$t_topic', '$t_detail', '$refer', '0')";

    if (mysqli_query($conn, $insert_query)) {
        echo '<script>alert("บันทึกข้อมูลเรียบร้อยแล้ว");window.location="page-topic.php";</script>';
    } else {
        echo "Error: " . $insert_query . "<br>" . mysqli_error($conn);
    }

    mysqli_close($conn);
}
?>
