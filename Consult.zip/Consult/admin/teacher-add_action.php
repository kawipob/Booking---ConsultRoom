<?php
    // เชื่อมต่อกับฐานข้อมูล
    include 'db_connect.php';
    $conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);

    // ตรวจสอบการเชื่อมต่อ
    if (!$conn) {
        die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // รับข้อมูลจากแบบฟอร์ม
        $email = $_POST['email'];
        $username = $_POST['username'];
        $password = md5($_POST['password']); // เข้ารหัสด้วย md5
        $fullname = $_POST['fullname'];
        $phone = $_POST['phone'];
        $structure = $_POST['structure'];
        $room = $_POST['room'];

        $role = 'teacher'; 
        $deleted_id = 0; 

        $image = $_FILES['image'];

        $allow = array('jpg', 'jpeg', 'png');
        $extension = pathinfo($image['name'], PATHINFO_EXTENSION);
        $fileActExt = strtolower($extension);
        $fileNew = uniqid() . "." . $fileActExt;
        $filePath = 'uploads/' . $fileNew;

        if (move_uploaded_file($image['tmp_name'], $filePath)) {
            $sql = $conn->prepare("INSERT INTO teacher (email, username, password, fullname, phone, structure, room, role, deleted_id, image) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            
            $sql->bind_param("ssssssssss", $email, $username, $password, $fullname, $phone, $structure, $room, $role, $deleted_id, $fileNew);
            $sql->execute();
        
            if ($sql->affected_rows > 0) {  
                echo '<script>alert("เพิ่มข้อมูลเรียบร้อยแล้ว");window.location="page-teacher.php"</script>';

            } else {
                echo '<script>alert("เพิ่มข้อมูลไม่สำเร็จครับ !!");window.location="page-teacher.php"</script>';
            }
        }
    }
?>
