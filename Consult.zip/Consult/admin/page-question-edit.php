<?php
session_start();
include 'db_connect.php';
$conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);

// เช็คการเชื่อมต่อ
if (!$conn) {
    die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
}


if (!isset($_SESSION['user_login'])) { // ถ้าไม่ได้เข้าระบบอยู่
    header("location: \Consult\login.php"); // redirect ไปยังหน้า login.php
    exit;
}

$user = $_SESSION['user_login'];
// กลับมาแก้ หลังจากเปลี่ยนที่เก็บข้อมูล
if ($user['level'] != 'admin') {
    echo '<script>alert("สำหรับผู้ดูแลระบบเท่านั้น");window.location="index.php";</script>';
    exit;
}
		// การออกจากระบบ
	if (isset($_GET['logout'])) {
		// ลบข้อมูล session ทั้งหมด
		session_unset();
		// ทำลาย session
		session_destroy();
		// Redirect ไปยังหน้าเข้าสู่ระบบหรือหน้าที่ต้องการ
		header("location: \Consult\login.php"); // เปลี่ยนเส้นทางไปยังหน้าที่ต้องการหลังจากออกจากระบบ
		exit;
	}

?>

<!DOCTYPE html>
<html>
<head>
    <!-- iCons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- ... ส่วนอื่น ๆ ... -->
    <title>แอดมิน | หน้าแดชบอร์ด</title>
    <!-- ใส่ CSS หรือ link เข้าไปที่นี่ (ถ้ามี) -->
    <link rel="stylesheet" href="css/teacher.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Work+Sans:ital@1&display=swap');
        body {
            font-family: 'Work Sans', sans-serif;
            margin: 0; 
        }
        /* สไตล์ CSS สำหรับ header */
        header {
            background-color: #ffffff;
            color: #000000;
            padding: 1px;
            margin-left: 20%;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h4 {
            margin-left: auto;
            margin: 30px ;
        }
        /* สไตล์ CSS สำหรับ sidebar */
        .sidebar {
            width: 250px;
            /* background-color: #f1f1f1; */
            background: #555555;
            color: #ffffff;
            height: 100%;
            position: fixed;
            left: 0;
            top: 0;
            overflow-x: hidden;
            padding-top: 20px;
        }
                /* สไตล์ CSS สำหรับลิงก์ */
        .sidebar a {
            display: block;
            padding: 20px 15px;
            text-decoration: none;
            color: #ffffff;
            font-size: 19px ;
        }
        .sidebar h2 {
            margin-left: 5px;
            margin-top: 5px;
        }
        h4 {
            color: gray;
        }
        .sidebar a:hover {
            background-color: #696969;
            color: #ffd700;
        }
        .content {
            margin-left: 20%;
            width: 75%;
            height: 100%;
            padding: 20px;
            background-color: #ffffff ;
            border-radius: 5px;
            box-shadow: 2px 2px 4px rgba(0.1, 0.1, 0.1, 0.3);
        }
        label {
            margin-bottom: 5px;
            display: block;
        }

        input[type="text"],
        input[type="password"],
        select {
            width: 30%;
            padding: 8px;
            margin-bottom: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            box-sizing: border-box;
            display: inline-block;
            vertical-align: middle;
        }
        input[type="submit"] {
            background-color: #ff9f00;
            color: #ffffff;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #ffb232;
            transition: 0.3s;
        }
        .back {
            color: #555555;
            padding: 9px 10px;
            text-decoration: none;
            border-radius: 5px;
        }
        .back:hover {
            color: #ffffff;
            background-color: #555555;
            border-color: #555555;
            transition: 0.4s;
        }

</style>

    </style>
</head>
<body>
<header>
    <h2>แก้ไข หัวข้อการปรึกษา</h2>
    <h4>ยินดีต้อนรับ <?php echo $user['fullname']; ?></h4>
</header>

<div class="sidebar">
    <h2>DMSU Consult Room</h2>
    <a href="admin.php"><i class="fas fa-home"></i> แดชบอร์ด</a>
    <a href="page-user.php"><i class="fas fa-users"></i> จัดการ ผู้ใช้งานทั้งหมด</a>
    <a href="page-teacher.php"><i class="fas fa-chalkboard-teacher"></i> จัดการ อาจารย์ที่ปรึกษา</a>
    <a href="page-topic.php"><i class="fas fa-tasks"></i> จัดการ หัวข้อการปรึกษา</a>
    <a href="page-question.php"><i class="fas fa-clipboard-check"></i></i> จัดการ แบบทดสอบ</a>
    <a href="page-profile.php"><i class="fas fa-user"></i> โปรไฟล์</a>
    <a href="?logout=true"><i class="fas fa-sign-out-alt"></i> ออกจากระบบ</a>
</div>


<div class="content">
        <form action="question-edit_action.php" method="POST">
            <?php 
                // // รับค่า topic_id ที่ส่งมาจาก URL
                $no = $_GET['no'];
                $sql = "SELECT * FROM question WHERE no = $no";
                $result = mysqli_query($conn,$sql);
        
                while ($row=mysqli_fetch_array($result)){
                    $topic_id = $row['topic_id'];
                    $q_question = $row['q_question'];
                    $choice_a = $row['choice_a'];
                    $choice_b = $row['choice_b'];
                    $choice_c = $row['choice_c'];
                    $choice_d = $row['choice_d']; 
                }
        
            ?>
        <label for="topic_id"> หัวข้อการปรึกษา : 
        <select id="topic_id" name="topic_id" required>
            <?php 
                            // ดึงข้อมูลจากตาราง topic
                            $sql = "SELECT topic_id, t_topic FROM topic";
                            $result = $conn->query($sql);
            
                            if ($result->num_rows > 0) {
                                // วนลูปเพื่อแสดงข้อมูลใน dropdown
                                while($row = $result->fetch_assoc()) {
                                    echo '<option class="option" value="' . $row["topic_id"] . '">' . $row["t_topic"] . '</option>';
                                }
                            
        
            ?>
        </select><br><br>
        </label>
        
            <input type="hidden" id="no" name="no" required value="<?php echo $no; ?>">

            <input type="hidden" id="topic_id" name="topic_id" required value="<?php echo $topic_id; ?>">

            <label for="q_question">โจทย์คำถาม : &nbsp;&nbsp;&nbsp;
                <input type="text" id="no" name="q_question" class="textquestion"  required value="<?php echo $q_question ?>">
            </label>
            
            <label for="choice_a">ตัวเลือก A : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <select class="space_choice" id="choice_a" name="choice_a" required>
                    <option class="option" value="แทบไม่มี"   
                    <?php if (isset($row["choice_a"]) && $row["choice_a"] == "แทบไม่มี") { echo "SELECTED"; } ?> >แทบไม่มี</option>

                    <option class="option" value="เป็นบางครั้ง" 
                    <?php  if (isset($row["choice_a"])  == "เป็นบางครั้ง") {echo "SELECTED";} ?> >เป็นบางครั้ง</option>

                    <option class="option" value="บ่อยครั้ง"   
                    <?php  if (isset($row["choice_a"])  == "เป็นบางครั้ง") {echo "SELECTED";} ?>>บ่อยครั้ง</option>

                    <option class="option" value="เป็นประจำ"  
                    <?php  if (isset($row["choice_a"])  == "เป็นประจำ") {echo "SELECTED";} ?>>เป็นประจำ</option>
                    
                </select><br>
            </label>

            <label for="choice_b" class="space_choice">ตัวเลือก B : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <select id="choice_b" name="choice_b" required>
                <option class="option" value="แทบไม่มี"   
                    <?php  if (isset($row["choice_b"])  == "แทบไม่มี") {echo "SELECTED";} ?> >แทบไม่มี</option>

                    <option class="option" value="เป็นบางครั้ง" 
                    <?php  if (isset($row["choice_b"]) == "เป็นบางครั้ง") {echo "SELECTED";} ?> >เป็นบางครั้ง</option>

                    <option class="option" value="บ่อยครั้ง"   
                    <?php  if (isset($row["choice_b"]) == "เป็นบางครั้ง") {echo "SELECTED";} ?>>บ่อยครั้ง</option>

                    <option class="option" value="เป็นประจำ"  
                    <?php  if (isset($row["choice_b"]) == "เป็นประจำ") {echo "SELECTED";} ?>>เป็นประจำ</option>
                    
                </select><br>
            </label>

            <label for="choice_c"class="space_choice">ตัวเลือก C : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <select id="choice_c" name="choice_c" required>
                    <option class="option" value="แทบไม่มี"   
                    <?php  if (isset($row["choice_c"]) == "แทบไม่มี") {echo "SELECTED";} ?> >แทบไม่มี</option>

                    <option class="option" value="เป็นบางครั้ง" 
                    <?php  if (isset($row["choice_c"]) == "เป็นบางครั้ง") {echo "SELECTED";} ?> >เป็นบางครั้ง</option>

                    <option class="option" value="บ่อยครั้ง"   
                    <?php  if (isset($row["choice_c"]) == "เป็นบางครั้ง") {echo "SELECTED";} ?>>บ่อยครั้ง</option>

                    <option class="option" value="เป็นประจำ"  
                    <?php  if (isset($row["choice_c"]) == "เป็นประจำ") {echo "SELECTED";} ?>>เป็นประจำ</option>

                </select><br>
            </label>

            <label for="choice_d" class="space_choice">ตัวเลือก D : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <select id="choice_d" name="choice_d" required>
                    <option class="option" value="แทบไม่มี"   
                    <?php  if (isset($row["choice_d"]) == "แทบไม่มี") {echo "SELECTED";} ?> >แทบไม่มี</option>

                    <option class="option" value="เป็นบางครั้ง" 
                    <?php  if (isset($row["choice_d"]) == "เป็นบางครั้ง") {echo "SELECTED";} ?> >เป็นบางครั้ง</option>

                    <option class="option" value="บ่อยครั้ง"   
                    <?php  if (isset($row["choice_d"]) == "เป็นบางครั้ง") {echo "SELECTED";} ?>>บ่อยครั้ง</option>

                    <option class="option" value="เป็นประจำ"  
                    <?php  if (isset($row["choice_d"]) == "เป็นประจำ") {echo "SELECTED";} ?>>เป็นประจำ</option>
                    
                </select><br><br>
            </label>

            <label for="answer_a">คะแนน ตัวเลือก A :  
                <input style="width: 10% ; text-align: center ;" type="text" id="answer_a" name="answer_a" value="0" disabled>
            </label>

            <label for="answer_b">คะแนน ตัวเลือก B :  
                <input style="width: 10% ; text-align: center ;" type="text" id="answer_b" name="answer_b" value="1" disabled>
            </label>

            <label for="answer_c">คะแนน ตัวเลือก C :  
                <input style="width: 10% ; text-align: center ;" type="text" id="answer_c" name="answer_c" value="2" disabled>
            </label>

            <label for="answer_d">คะแนน ตัวเลือก D :  
                <input style="width: 10% ; text-align: center ;" type="text" id="answer_d" name="answer_d" value="3" disabled>
            </label>

            <!-- <input type="hidden" id="deleted_id" name="deleted_id" required value="<?php echo $deleted_id; ?>"> -->

            <input type="submit" value="บันทึก"> <a href="page-question.php" class="back">ย้อนกลับ</a>
        
            <?php
                } else {
                    echo "Teacher not found";
                }    
            ?>

        </form>
    </div><br><br>
</body>     
</html>
