<?php
    session_start();
    include 'db_connect.php';
    $conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);
    
    // Check connection
    if (!$conn) {
        die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
    }

    $no = $_POST["no"];
    $topic_id = $_POST['topic_id'];
    $q_question = $_POST['q_question'];
    $choice_a = $_POST['choice_a'];
    $choice_b = $_POST['choice_b'];
    $choice_c = $_POST['choice_c'];
    $choice_d = $_POST['choice_d'];

    // Prepared statement to prevent SQL injection
    $sql = "UPDATE question SET topic_id=?, q_question=?, choice_a=?, choice_b=?, choice_c=?, choice_d=? WHERE no=?";
    $stmt = mysqli_prepare($conn, $sql);

    // Check if the prepare() call succeeded
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'issssss', $topic_id, $q_question, $choice_a, $choice_b, $choice_c, $choice_d, $no);
        $result = mysqli_stmt_execute($stmt);

        if ($result) {
            echo '<script>alert("แก้ไขข้อมูลเรียบร้อยแล้ว");window.location="page-question.php";</script>';
            exit();
        } else {
            echo "เกิดข้อผิดพลาดในการอัปเดตข้อมูล: " . mysqli_stmt_error($stmt);
        }
    } else {
        echo "เกิดข้อผิดพลาดในการเตรียมคำสั่ง SQL: " . mysqli_error($conn);
    }

    mysqli_stmt_close($stmt);
    mysqli_close($conn);
?>
