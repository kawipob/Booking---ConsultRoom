<?php
session_start();
include 'db_connect.php';
$conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);

if(isset($_GET['topic_id'])) {
    $topic_id = $_GET['topic_id'];
    
    // Assuming $conn is your database connection
    $query = "UPDATE topic SET deleted_id = 1 WHERE topic_id = $topic_id";
    
    if ($conn->query($query) === TRUE) {

        echo '<script>alert("ลบข้อมูลแบบ SoftDelete ");window.location="page-topic.php";</script>';
        exit();
    } else {
        echo "Error updating record: " . $conn->error;
    }
} else {
    echo "Teacher ID not provided.";
}
?>