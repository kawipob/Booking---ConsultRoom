<?php
session_start();
include 'db_connect.php';
$conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);

// เช็คการเชื่อมต่อ
if (!$conn) {
    die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
}


if (!isset($_SESSION['user_login'])) { // ถ้าไม่ได้เข้าระบบอยู่
    header("location: \Consult\login.php"); // redirect ไปยังหน้า login.php
    exit;
}

$user = $_SESSION['user_login'];
// กลับมาแก้ หลังจากเปลี่ยนที่เก็บข้อมูล
if ($user['level'] != 'admin') {
    echo '<script>alert("สำหรับผู้ดูแลระบบเท่านั้น");window.location="index.php";</script>';
    exit;
}
		// การออกจากระบบ
	if (isset($_GET['logout'])) {
		// ลบข้อมูล session ทั้งหมด
		session_unset();
		// ทำลาย session
		session_destroy();
		// Redirect ไปยังหน้าเข้าสู่ระบบหรือหน้าที่ต้องการ
		header("location: \Consult\login.php"); // เปลี่ยนเส้นทางไปยังหน้าที่ต้องการหลังจากออกจากระบบ
		exit;
	}

// รับค่า topic_id ที่ส่งมาจาก URL
if (isset($_GET['topic_id'])) {
    $topic_id = $_GET['topic_id'];

    // ทำการ query ข้อมูลโดยกรองด้วย topic_id โดยใช้ Parameterized Query เพื่อป้องกัน SQL Injection
    $sql = "SELECT * FROM question WHERE topic_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $topic_id); // กำหนดค่า topic_id ให้กับ Parameter ใน query
    $stmt->execute();
    $result_questions = $stmt->get_result(); // รับผลลัพธ์จาก query

    // ... (ส่วนของ HTML และการแสดงผลตารางข้อมูล)

} else {
    echo "ไม่พบ topic_id";
}

?>

<!DOCTYPE html>
<html>
<head>
    <!-- iCons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- ICON LOGO WEB -->
    <link rel="icon" type="image/นามสกุลไฟล์" href="image/satit student.png" />
    <title>แอดมิน | หน้าแดชบอร์ด</title>
    <!-- ใส่ CSS -->
    <link rel="stylesheet" href="css/page-question-add.css">
</head>
<body>
<header>
    <h2>แบบทดสอบ</h2>
    <h4>ยินดีต้อนรับ <?php echo $user['fullname']; ?></h4>
</header>

<div class="sidebar">
    <h2>DMSU Consult Room</h2>
    <a href="admin.php"><i class="fas fa-home"></i> แดชบอร์ด</a>
    <a href="page-user.php"><i class="fas fa-users"></i> จัดการ ผู้ใช้งานทั้งหมด</a>
    <a href="page-teacher.php"><i class="fas fa-chalkboard-teacher"></i> จัดการ อาจารย์ที่ปรึกษา</a>
    <a href="page-topic.php"><i class="fas fa-tasks"></i> จัดการ หัวข้อการปรึกษา</a>
    <a href="page-question.php"><i class="fas fa-clipboard-check"></i></i> จัดการ แบบทดสอบ</a>
    <a href="page-profile.php"><i class="fas fa-user"></i> โปรไฟล์</a>
    <a href="?logout=true"><i class="fas fa-sign-out-alt"></i> ออกจากระบบ</a>
</div>

<div class="content">
    <table border="1">
        <thead>
            <tr>
                <th>ลำดับ</th>
                <th>หัวข้อการปรึกษา</th>
                <th>ตัวเลือก A</th>
                <th>ตัวเลือก B</th>
                <th>ตัวเลือก C</th>
                <th>ตัวเลือก D</th>
                <th >แก้ไข</th>
                <th >ลบ</th>

            </tr>
        </thead>
        <tbody>
        <?php
            $count = 1;
            if ($result_questions->num_rows > 0) {
                while ($row = $result_questions->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $count . "</td>";
                    echo "<td style='text-align: left;'>" . $row['q_question'] . "</td>";
                    echo "<td>" . $row['choice_a'] . "</td>";
                    echo "<td>" . $row['choice_b'] . "</td>";
                    echo "<td>" . $row['choice_c'] . "</td>";
                    echo "<td>" . $row['choice_d'] . "</td>";
                    echo "<td><a href='page-question-edit.php?no=" . $row['no'] . "' class='button-edit'><button><i class='fas fa-edit'></i></button></a></td>";
                    echo "<td><a href='question-delete_action.php?no=" . $row['no'] . "' class='button-delete'><button><i class='fas fa-trash-alt'></i></button></a></td>";
                    echo "</tr>";
                    $count++;
                }
            } else {
                echo "<tr><td colspan='11'>ไม่พบข้อมูล</td></tr>";
            }
        ?>
        </tbody>
    </table>
</div><br><br>

<div class="formcontent">
        <h2>เพิ่ม แบบทดสอบ</h2>
        <form action="question-add_action.php" method="POST">
        <label for="topic_id"> หัวข้อการปรึกษา : 
        <select id="topic_id" name="topic_id" required>
            <?php 
                            // ดึงข้อมูลจากตาราง topic
                            $sql = "SELECT topic_id, t_topic FROM topic";
                            $result = $conn->query($sql);
            
                            if ($result->num_rows > 0) {
                                // วนลูปเพื่อแสดงข้อมูลใน dropdown
                                while($row = $result->fetch_assoc()) {
                                    echo '<option class="option" value="' . $row["topic_id"] . '">' . $row["t_topic"] . '</option>';
                                }
                            } else
            
            ?>
        </select><br><br>
        </label>

            <label for="q_question">โจทย์คำถาม : &nbsp;&nbsp;&nbsp;
                <input type="text" id="q_question" name="q_question" class="textquestion" required>
            </label>
            
            <label for="choice_a">ตัวเลือก A : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <select class="space_choice" id="choice_a" name="choice_a" required>
                    <option class="option" value="แทบไม่มี">แทบไม่มี</option>
                    <option class="option" value="เป็นบางครั้ง">เป็นบางครั้ง</option>
                    <option class="option" value="บ่อยครั้ง">บ่อยครั้ง</option>
                    <option class="option" value="เป็นประจำ">เป็นประจำ</option>
                </select><br>
            </label>

            <label for="choice_b" class="space_choice">ตัวเลือก B : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <select id="choice_b" name="choice_b" required>
                    <option class="option" value="แทบไม่มี">แทบไม่มี</option>
                    <option class="option" value="เป็นบางครั้ง">เป็นบางครั้ง</option>
                    <option class="option" value="บ่อยครั้ง">บ่อยครั้ง</option>
                    <option class="option" value="เป็นประจำ">เป็นประจำ</option>
                </select><br>
            </label>

            <label for="choice_c"class="space_choice">ตัวเลือก C : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <select id="choice_c" name="choice_c" required>
                    <option class="option" value="แทบไม่มี">แทบไม่มี</option>
                    <option class="option" value="เป็นบางครั้ง">เป็นบางครั้ง</option>
                    <option class="option" value="บ่อยครั้ง">บ่อยครั้ง</option>
                    <option class="option" value="เป็นประจำ">เป็นประจำ</option>
                </select><br>
            </label>

            <label for="choice_d" class="space_choice">ตัวเลือก D : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <select id="choice_d" name="choice_d" required>
                    <option class="option" value="แทบไม่มี">แทบไม่มี</option>
                    <option class="option" value="เป็นบางครั้ง">เป็นบางครั้ง</option>
                    <option class="option" value="บ่อยครั้ง">บ่อยครั้ง</option>
                    <option class="option" value="เป็นประจำ">เป็นประจำ</option>
                </select><br><br>
            </label>

            <label for="answer_a">คะแนน ตัวเลือก A :  
                <input style="width: 10% ; text-align: center ;" type="text" id="answer_a" name="answer_a" value="0" disabled>
            </label>

            <label for="answer_b">คะแนน ตัวเลือก B :  
                <input style="width: 10% ; text-align: center ;" type="text" id="answer_b" name="answer_b" value="1" disabled>
            </label>

            <label for="answer_c">คะแนน ตัวเลือก C :  
                <input style="width: 10% ; text-align: center ;" type="text" id="answer_c" name="answer_c" value="2" disabled>
            </label>

            <label for="answer_d">คะแนน ตัวเลือก D :  
                <input style="width: 10% ; text-align: center ;" type="text" id="answer_d" name="answer_d" value="3" disabled>
            </label>

            <input type="submit" value="บันทึก"> <a href="page-question.php" class="back">ย้อนกลับ</a>
        
        </form>
    </div><br><br>

</body>     
</html>
