<?php
session_start();
include 'db_connect.php';
$conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);

// เช็คการเชื่อมต่อ
if (!$conn) {
    die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
}


if (!isset($_SESSION['user_login'])) { // ถ้าไม่ได้เข้าระบบอยู่
    header("location: \Consult\login.php"); // redirect ไปยังหน้า login.php
    exit;
}

$user = $_SESSION['user_login'];
// กลับมาแก้ หลังจากเปลี่ยนที่เก็บข้อมูล
if ($user['level'] != 'admin') {
    echo '<script>alert("สำหรับผู้ดูแลระบบเท่านั้น");window.location="index.php";</script>';
    exit;
}
		// การออกจากระบบ
	if (isset($_GET['logout'])) {
		// ลบข้อมูล session ทั้งหมด
		session_unset();
		// ทำลาย session
		session_destroy();
		// Redirect ไปยังหน้าเข้าสู่ระบบหรือหน้าที่ต้องการ
		header("location: \Consult\login.php"); // เปลี่ยนเส้นทางไปยังหน้าที่ต้องการหลังจากออกจากระบบ
		exit;
	}

?>

<!DOCTYPE html>
<html>
<head>
    <!-- iCons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- ... ส่วนอื่น ๆ ... -->
    <title>แอดมิน | หน้าแดชบอร์ด</title>
    <!-- ใส่ CSS หรือ link เข้าไปที่นี่ (ถ้ามี) -->
    <link rel="stylesheet" href="css/page-topic-edit.css">
<style>

</style>

    </style>
</head>
<body>
<header>
    <h2>แก้ไข หัวข้อการปรึกษา</h2>
    <h4>ยินดีต้อนรับ <?php echo $user['fullname']; ?></h4>
</header>

<div class="sidebar">
    <h2>DMSU Consult Room</h2>
    <a href="admin.php"><i class="fas fa-home"></i> แดชบอร์ด</a>
    <a href="page-user.php"><i class="fas fa-users"></i> จัดการ ผู้ใช้งานทั้งหมด</a>
    <a href="page-teacher.php"><i class="fas fa-chalkboard-teacher"></i> จัดการ อาจารย์ที่ปรึกษา</a>
    <a href="page-topic.php"><i class="fas fa-tasks"></i> จัดการ หัวข้อการปรึกษา</a>
    <a href="page-question.php"><i class="fas fa-clipboard-check"></i></i> จัดการ แบบทดสอบ</a>
    <a href="page-profile.php"><i class="fas fa-user"></i> โปรไฟล์</a>
    <a href="?logout=true"><i class="fas fa-sign-out-alt"></i> ออกจากระบบ</a>
</div>


<div class="content">

        <form action="topic-edit_action.php" method="POST">              
        
        <?php

        $topic_id = $_GET['topic_id'];
        $sql = "SELECT * FROM topic WHERE topic_id = $topic_id";
        $result = mysqli_query($conn,$sql);

        while ($row=mysqli_fetch_array($result)){
            $t_topic = $row['t_topic'];
            $t_detail = $row['t_detail'];
            $refer = $row['refer']; 
            $deleted_id = $row['deleted_id'];  
        }
        ?>
            <input type="hidden" id="topic_id" name="topic_id" required value="<?php echo $topic_id; ?>"><br><br>

            <label for="t_topic">หัวข้อการปรึกษา : </label><br>
            <input type="text" id="t_topic" name="t_topic" required value="<?php echo $t_topic; ?>"><br><br>

            <label for="t_detail">รายละเอียด : </label><br>
            <input type="text" id="t_detail" name="t_detail" required value="<?php echo $t_detail; ?>"><br><br>

            <label for="refer">อ้างอิง :</label><br>
            <input type="text" id="refer" name="refer" required value="<?php echo $refer; ?>"><br><br>

            <input type="hidden" id="deleted_id" name="deleted_id" required value="<?php echo $deleted_id; ?>">

            <input type="submit" value="บันทึก" name="update"> <a href="page-topic.php" class="back">ย้อนกลับ</a>
        </form>

    </div>
</body>     
</html>
