<?php
session_start();
include 'db_connect.php';
$conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);

// เช็คการเชื่อมต่อ
if (!$conn) {
    die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
}

if (!isset($_SESSION['user_login'])) { // ถ้าไม่ได้เข้าระบบอยู่
    header("location: \Consult\login.php"); // redirect ไปยังหน้า login.php
    exit;
}

$user = $_SESSION['user_login'];
// กลับมาแก้ หลังจากเปลี่ยนที่เก็บข้อมูล
if ($user['level'] != 'admin') {
    echo '<script>alert("สำหรับผู้ดูแลระบบเท่านั้น");window.location="index.php";</script>';
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Access and sanitize form data
    $topic_id = $_POST['topic_id'];
    $q_question = $_POST['q_question']; // คำถามที่ผู้ใช้กรอก
    $choice_a = $_POST['choice_a'];
    $choice_b = $_POST['choice_b'];
    $choice_c = $_POST['choice_c'];
    $choice_d = $_POST['choice_d'];
    $answer_a = $_POST['answer_a'];
    $answer_b = $_POST['answer_b'];
    $answer_c = $_POST['answer_c'];
    $answer_d = $_POST['answer_d'];

    // คำสั่ง SQL เพื่อเพิ่มข้อมูลลงในตาราง question (เพื่อสร้างคำถาม)
    $insert_query = "INSERT INTO question (topic_id, q_question, choice_a, choice_b, choice_c, choice_d, answer_a, answer_b, answer_c, answer_d) 
    VALUES ('$topic_id', '$q_question', '$choice_a', '$choice_b', '$choice_c', '$choice_d', '0', '1', '2', '3')";

    if (mysqli_query($conn, $insert_query)) {
        echo '<script>alert("เพิ่มข้อมูลเรียบร้อยแล้ว");window.location="page-question.php"</script>';
    } else {
        echo "Error: " . $insert_query . "<br>" . mysqli_error($conn);
    }

    mysqli_close($conn);
}

?>
