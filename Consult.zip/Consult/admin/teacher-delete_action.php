<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_login']) || $_SESSION['user_login']['level'] !== 'admin') {
    header("location: \Consult\login.php");
    exit;
}

if (isset($_GET['teacher_id'])) {
    $topic_id = $_GET['teacher_id'];

    $stmt = $conn->prepare("DELETE FROM teacher WHERE  teacher_id = ?");
    $stmt->bind_param("i", $topic_id);
    $stmt->execute();

    $stmt->close();
    $conn->close();

    echo '<script>alert("ลบข้อมูลเรียบร้อยแล้ว");window.location="page-teacher.php";</script>';
    exit;
} else {
    header("location: \Consult\admin.php");
    exit;
}
?>
