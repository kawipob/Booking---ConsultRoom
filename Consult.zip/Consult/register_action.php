<?php
    // เชื่อมต่อกับฐานข้อมูล
    include 'db_connect.php';
    $conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);

    // ตรวจสอบการเชื่อมต่อ
    if (!$conn) {
        die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // รับข้อมูลจากแบบฟอร์ม
        $data = $_POST;
        $fullname = $_POST['fullname'];
        $username = $_POST['username'];
        $phone = $_POST['phone'];
        $password = md5($_POST['password']); // เข้ารหัสด้วย md5
        $c_password = $_POST['c_password'];

        // ตรวจสอบว่ารหัสผ่านตรงกันหรือไม่
        if ($password !== md5($c_password)) {
            echo '<script>alert("รหัสผ่านไม่ตรงกัน กรุณาลองใหม่อีกครั้ง");window.location="register.php";</script>';
        } else {


        $check_fullname = "SELECT * FROM users WHERE fullname = '$fullname'";
        $result_fullname = mysqli_query($conn, $check_fullname);
        
        if (mysqli_num_rows($result_fullname) > 0) {
            echo '<script>alert("ชื่อ-นามสกุลนี้เคยสมัครสมาชิกเเล้ว");window.location="register.php";</script>';
        } else {
            // ตรวจสอบว่ามีชื่อผู้ใช้หรือไม่
            $check_username = "SELECT * FROM users WHERE username = '$username'";
            $result_username = mysqli_query($conn, $check_username);
        
            if (mysqli_num_rows($result_username) > 0) {
                echo '<script>alert("รหัสนักเรียน นี้เคยสมัครสมาชิกเเล้ว");window.location="register.php";</script>';
            } else {
                // ตรวจสอบว่ามีหมายเลขโทรศัพท์หรือไม่
                $check_phone = "SELECT * FROM users WHERE phone = '$phone'";
                $result_phone = mysqli_query($conn, $check_phone);
        
                if (mysqli_num_rows($result_phone) > 0) {
                    echo '<script>alert("หมายเลขโทรศัพท์นี้ถูกใช้แล้ว กรุณาใช้หมายเลขโทรศัพท์อื่น");window.location="register.php";</script>';
                } else {
                    // ทำการเพิ่มข้อมูลลงในฐานข้อมูล
                    $sql = "INSERT INTO users (fullname, username, phone, password,  role )
                    VALUES ( '$fullname', '$username', '$phone', '$password', 'user' )";
        
                    if (mysqli_query($conn, $sql)) {
                        echo '<script>alert("สมัครสมาชิก เรียบร้อยแล้ว");window.location="login.php";</script>';
                    } else {
                        echo "เกิดข้อผิดพลาดในไม่สามารถสมัครสมาชิกได้: " . mysqli_error($conn);
                    }
                }
            }
            mysqli_close($conn);
        }
    }
}
?>
