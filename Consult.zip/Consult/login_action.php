<?php
session_start(); // เปิดใช้งาน session
include_once("./function.php");

if (isset($_SESSION['user_login'])) { // ถ้าเข้าระบบอยู่
    header("location: index.php"); // redirect ไปยังหน้า index.php
    exit;
}

$objCon = connectDB();
$username = mysqli_real_escape_string($objCon, $_POST['username']);
$password = mysqli_real_escape_string($objCon, $_POST['password']);

$strSQL = "SELECT teacher_id AS id, fullname, role FROM teacher WHERE username = '$username' AND password = md5('$password')
UNION 
SELECT id, fullname, role FROM users WHERE username = '$username' AND password = md5('$password')
UNION
SELECT id AS id, fullname, role FROM admin WHERE username = '$username' AND password = md5('$password')";

$objQuery = mysqli_query($objCon, $strSQL);
$row = mysqli_num_rows($objQuery);

if ($row) {
    $res = mysqli_fetch_assoc($objQuery);
    $_SESSION['user_login'] = array('id' => $res['id'], 'fullname' => $res['fullname'], 'username' => $res['username'], 'level' => $res['role']);

    if ($res['role'] === 'admin') {
        echo '<script>alert("ยินดีต้อนรับคุณ ' . $res['fullname'] . '");window.location="admin/admin.php";</script>';

    } elseif ($res['role'] === 'teacher') {
        echo '<script>alert("ยินดีต้อนรับอาจารย์ ' . $res['fullname'] . ' อาจารย์ที่ปรึกษา");window.location="teacher/teacher.php";</script>';

    } else {
        echo '<script>alert("ยินดีต้อนรับคุณ ' . $res['fullname'] . '");window.location="student/student.php";</script>';
    }
} else {
    echo '<script>alert("username หรือ password ไม่ถูกต้อง!!");window.location="login.php";</script>';
}

?>

