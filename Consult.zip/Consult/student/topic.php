<?php 
    session_start();
    include 'db_connect.php';
    $conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);

// เช็คการเชื่อมต่อ
if (!$conn) {
    die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
}


if (!isset($_SESSION['user_login'])) {
    header("location: \Consult\login.php"); 
    exit;
}

$user = $_SESSION['user_login'];
if ($user['level'] != 'user') {
    echo '<script>alert("ยินดีต้อนรับนักเรียนทุกคน");window.location="index.php";</script>';
    exit;
}
		// การออกจากระบบ
	if (isset($_GET['logout'])) {
		
		session_unset();
		
		session_destroy();
		
		header("location: \Consult\login.php"); 
		exit;
	}
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- ICON LOGO WEB -->
    <link rel="icon" type="image/นามสกุลไฟล์" href="image/satit student.png" />
    <title>นักเรียน | เลือกอาจารย์ที่ปรึกษา</title>
    <!-- Bootrap  container -->
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <!-- CSS -->
    <link rel="stylesheet" href="css/topic.css?v=9999">
<body>
    <!-- navbar -->
    <nav>
        <ul>
            <li><a href="student.php">หน้าหลัก</a></li>
            <li><a href="topic.php">เลือกหัวข้อการปรึกษา</a></li>
            <li><a href="#">การเข้าพบ</a></li>
            <li><a href="history.php">ประวัติการจอง</a></li>
            <li><a href="?logout=true">ออกจากระบบ</a></li>
        </ul>
    </nav>

    <div class="container"><br>
        <h1 class="text-center">เลือกหัวข้อการปรึกษา</h1>
        <br><br>
        <div class="row">
            <?php

                $sql = "SELECT * FROM topic";
                $query = $conn->query($sql);

                if ($query->num_rows > 0) {
                    while ($row = $query->fetch_assoc()) {
            ?>
        <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
            <div class="profile-card bg-white shadow mb-4 text-center rounded-lg p-4 position-relative h-100">

                <div class="profile-card_details"><br>
                    <h3><?php echo $row['t_topic']; ?></h3><br> 
                    <p class="text-muted"><?php echo $row['t_detail']; ?></p>
                </div>

                <div class="profile-card_social text-center p-4">
                    <a href="question.php?topic_id=<?php echo $row['topic_id']; ?>">เลือกหัวข้อการปรึกษา</a>
                </div>

            </div>
        </div>
<?php
    }
} else {
    echo "ไม่พบข้อมูล";
}

$conn->close();
            ?>
        </div>
    </div><br><br><br>
</body>
</html>
