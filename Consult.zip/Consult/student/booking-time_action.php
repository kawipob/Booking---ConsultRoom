<?php
    session_start();
    include 'db_connect.php';
    $conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);

  // เช็คการเชื่อมต่อ
  if (!$conn) {
      die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
  }


  if (!isset($_SESSION['user_login'])) {
      header("location: \Consult\login.php"); 
      exit;
  }

  $user = $_SESSION['user_login'];
  if ($user['level'] != 'user') {
      echo '<script>alert("ยินดีต้อนรับนักเรียนทุกคน");window.location="index.php";</script>';
      exit;
  }
		// การออกจากระบบ
	if (isset($_GET['logout'])) {
		
		session_unset();
		
		session_destroy();
		
		header("location: \Consult\login.php"); 
		exit;
	}

	
	$message = 	"\n".
                "ห้องพัฒนาสุขภาวะ".
                "\n".
				" รหัสนักเรียน : ".$_POST['booking_stdnumber']."\n".
				" ชื่อผู้จอง : ".$_POST['booking_name']."\n".
				" หัวข้อการปรึกษา : ".$_POST['booking_topic']."\n".
                " คะแนนทำแบบทดสอบ : ".$_POST['question_score']."\n".
				" อาจารย์ที่ปรึกษา : ".$_POST['teacher_fullname']."\n".
				" เวลาที่ต้องการจอง : ".$_POST['booking_time']."\n".
				" วันที่จอง : ".$_POST['booking_date'];
	
	$token = "BmFJ3MyV7N4wwWDMADa88jOMsLTKVQFx5JuKOi6XhLI"; // ใส่ Token ที่ได้จากการ Generate
	
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "https://notify-api.line.me/api/notify");
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, "message=$message");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_HTTPHEADER, [
		"Authorization: Bearer $token",
		"Content-Type: application/x-www-form-urlencoded"
	]);
	
	$result = curl_exec($ch);
	curl_close($ch);
	
	// Check result (optional)
	if ($result === false) {
		echo "Error sending message";
	} else {
		echo "Message sent successfully";
	}
	
	
    
    if (isset($_POST['tbl_id']) && isset($_POST['booking_stdnumber']) && isset($_POST['booking_date'])) {
	
    
    //ประกาศตัวแปรรับค่าจากฟอร์ม
    $teacher_id = $_POST['teacher_id'];
    $std_id = $_POST['std_id'];
    $teacher_fullname = $_POST['teacher_fullname'];
    $booking_stdnumber = $_POST['booking_stdnumber'];
    $booking_name = $_POST['booking_name'];
    $booking_topic = $_POST['booking_topic'];
    $question_score = $_POST['question_score'];
    $booking_time = $_POST['booking_time']; 
    $booking_date = $_POST['booking_date'];
    $tbl_id = $_POST['tbl_id'];
    $dateCreate = date('Y-m-d H:i:s');
    $cancel_id = $_POST['cancel_id '];
 
    //insert booking
    mysqli_query($conn, "BEGIN");

    $sqlInsertBooking	= "INSERT INTO  booking values(null,'$teacher_id','$std_id','$teacher_fullname','$booking_stdnumber','$booking_name','$booking_topic','$question_score','$booking_time','$booking_date','$tbl_id','$dateCreate','0')";

    $rsInsertBooking	= mysqli_query($conn, $sqlInsertBooking);

    
    $sqlUpdate ="UPDATE booking_time SET booking_status=1 WHERE id = $tbl_id"; //1=จอง

    $rsUpdate = mysqli_query($conn, $sqlUpdate);
    
    
    if($rsInsertBooking && $rsUpdate){
            mysqli_query($conn, "COMMIT");
            $_SESSION['success'] = "การจองสำเร็จครับ";
            header("location: booking-detail.php?booking_stdnumber=" . $booking_stdnumber);
        }else{
            mysqli_query($conn, "ROLLBACK");  
            $msg = 'บันทึกข้อมูลไม่สำเร็จ กรุณาติดต่อเจ้าหน้าที่ค่ะ  <a href="topic.php"> กลับหน้าหลัก </a>';	
        }
    } //iset 
    else{
        header("Location: student.php");	
    }
?>