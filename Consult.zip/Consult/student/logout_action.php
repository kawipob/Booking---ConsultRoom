<?php
    session_start();
    session_destroy(); // ลบ session ทั้งหมด
    header("location: \Consult\welcome.php"); // redirect ไปยังหน้า welcome
?>
