<?php
session_start();
include 'db_connect.php';
$conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);

if(isset($_GET['no'])) {
    $no = $_GET['no'];
    
    // Assuming $conn is your database connection
    $query = "UPDATE booking SET cancel_id = 1 WHERE no = $no";
    
    if ($conn->query($query) === TRUE) {

        echo '<script>alert("ยกเลิกการจองเรียบร้อย ");window.location="student.php";</script>';
        exit();
    } else {
        echo "Error updating record: " . $conn->error;
    }
} else {
    echo "Teacher ID not provided.";
}
?>