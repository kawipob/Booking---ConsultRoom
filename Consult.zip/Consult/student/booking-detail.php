<?php
    session_start();
    include 'db_connect.php';
    $conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);

  // เช็คการเชื่อมต่อ
  if (!$conn) {
      die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
  }


  if (!isset($_SESSION['user_login'])) {
      header("location: \Consult\login.php"); 
      exit;
  }

  $user = $_SESSION['user_login'];
  if ($user['level'] != 'user') {
      echo '<script>alert("ยินดีต้อนรับนักเรียนทุกคน");window.location="index.php";</script>';
      exit;
  }
		// การออกจากระบบ
	if (isset($_GET['logout'])) {
		
		session_unset();
		
		session_destroy();
		
		header("location: \Consult\login.php"); 
		exit;
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- ICON LOGO WEB -->
    <link rel="icon" type="image/นามสกุลไฟล์" href="image/satit student.png" />
    <title>นักเรียน | การเข้าพบ</title>
    <!-- CSS -->
    <link rel="stylesheet" href="css/booking-detail.css?v=9999">

<body>
    <!-- navbar -->
    <nav>
        <ul>
            <li><a href="student.php">หน้าหลัก</a></li>
            <li><a href="#">เลือกหัวข้อการปรึกษา</a></li>
            <li><a href="#">การเข้าพบ</a></li>
            <li><a href="history.php">ประวัติการจอง</a></li>
            <li><a href="?logout=true"><i class="fas fa-sign-out-alt"></i> ออกจากระบบ</a></li>
        </ul>
    </nav>

    <h2>รายการจองล่าสุด</h2>
    <hr>
    <table>
        <thead>
            <th>หัวข้อการปรึกษา</th>
            <th>อาจารย์ที่ปรึกษา</th>
            <th>เวลาที่จอง</th>
            <th>วันที่จอง</th>
            <th>รีวิว</th>
            <th>การจอง</th>
        </thead>
        <tbody>
        <?php
            if(isset($_GET['booking_stdnumber'])) {
                $booking_stdnumber = $_GET['booking_stdnumber'];

                // Prepare SQL query with a WHERE clause to filter results by booking_stdnumber
                $sql = "SELECT * FROM booking WHERE booking_stdnumber = ? ORDER BY booking_date DESC, booking_time DESC LIMIT 1";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("s", $booking_stdnumber);  
                $stmt->execute(); 

                $result = $stmt->get_result(); 

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['booking_topic'] . "</td>";
                        echo "<td>" . $row['teacher_fullname'] . "</td>";
                        echo "<td>" . $row['booking_time'] . "</td>";
                        echo "<td>" . $row['booking_date'] . "</td>";
                        echo "<td><a class='button' href='reviews.php'>รีวิว</a></td>";
                        echo "<td><a id='cancelButton' class='button' href='booking-cancel.php?no=" . $row['no'] . "'>ยกเลิก</a></td>";
                        echo "</tr>";
                        echo "<tr>";
                        echo "<td colspan='6'><h4>โปรดอยู่หน้านี้จนกว่าจะเข้าห้องพัฒนาสุขภาวะ ขอบคุณครับ</h4></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6'>ไม่พบข้อมูล</td></tr>";
                }
            } else {
                echo "<tr><td colspan='6'>ไม่พบข้อมูล</td></tr>";
            }

        ?>
        </tbody>
    </table>
    
    <script>
        // สคริปต์ JavaScript สำหรับการคลิกปุ่มรีวิว
        const buttons = document.querySelectorAll('.button');
        buttons.forEach(button => {
            button.addEventListener('click', function() {
                this.classList.add('reviewed');
                this.textContent = 'รีวิวแล้ว';
            });
        });
    </script>

    <script>
    // สคริปต์ที่จะทำให้ปุ่มหายไปหลังจาก 40 นาที
    setTimeout(function() {
        var button = document.getElementById('cancelButton');
        if (button) {
            button.style.display = 'none'; // ซ่อนปุ่ม
        }
    }, 2400000); // 40 นาที = 40 * 60 * 1000 (แปลงเป็นมิลลิวินาที) 2400000
    </script>

</body>
</html>


