<?php
session_start();
include 'db_connect.php';
$conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);

// เช็คการเชื่อมต่อ
if (!$conn) {
    die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
}

if (!isset($_SESSION['user_login'])) {
    header("location: \Consult\login.php");
    exit;
}

$user = $_SESSION['user_login'];
if ($user['level'] != 'user') {
    echo '<script>alert("ยินดีต้อนรับนักเรียนทุกคน");window.location="index.php";</script>';
    exit;
}

// การออกจากระบบ
if (isset($_GET['logout'])) {

    session_unset();

    session_destroy();

    header("location: \Consult\login.php");
    exit;
}

$topic_id = '?'; // แทนค่านี้ด้วยค่าจริง
if(isset($_GET['topic_id'])) {
    $topic_id = $_GET['topic_id'];
}

$choice = $_POST['choice'];
// ผลคะแนนรวมที่ทำได้ 
$sum_score = 0;
$sql_question = "SELECT * FROM question";
$query_question = mysqli_query($conn, $sql_question);
// จำนวนข้อทั้งหมด คะแนนเต็ม
$count_question = mysqli_num_rows($query_question);

if (empty($choice)) {
    echo "<script>alert('คุณยังไม่ได้ทำแบบทดสอบ');window.location.href='teacher.php?topic_id=" . $topic_id . "&sum_score=0';</script>";
    exit();
}

foreach ($choice as $key => $value) {
    $sql = "SELECT * FROM question where no = '$key'";

    $query = mysqli_query($conn, $sql);

    $data = mysqli_fetch_array($query);

    if ($data['answer_d'] == $value) {
        $sum_score += 3;
    } else if ($data['answer_c'] == $value) {
        $sum_score += 2;
    } else if ($data['answer_b'] == $value) {
        $sum_score += 1;
    } else if ($data['answer_a'] == $value) {
        $sum_score += 0;
    } else {
        $sum_score += 0;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- ICON LOGO WEB -->
    <link rel="icon" type="image/นามสกุลไฟล์" href="image/welcome.png" />
    <title>นักเรียน | คะแนนทำแบบทดสอบ</title>
    <!-- CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <!-- ตกแต่ง -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.1/flowbite.min.css" rel="stylesheet" />
    <!-- CSS -->
    <link rel="stylesheet" href="css/question-score.css">
</head>

<body>
    <!-- navbar -->
    <nav>
        <ul>
            <li><a href="student.php">หน้าหลัก</a></li>
            <li><a href="#">เลือกหัวข้อการปรึกษา</a></li>
            <li><a href="#">การเข้าพบ</a></li>
            <li><a href="#">ประวัติการจอง</a></li>
            <li><a href="?logout=true">ออกจากระบบ</a></li>
        </ul>
    </nav>

    <div class="continue">
        <div class="col-md-12"><br>
            <p class="textpoint">คะแนนของคุณ</p> <br><br>
            <p class="score"> <?php echo $sum_score ?></p>
            <br><br>
            <p class="scoredetail">
                <?php
                if ($sum_score >= 0 && $sum_score <= 4) {
                    echo "แปลผลคะแนนโดยรวม : มีความเคลียดน้อย";
                } else if ($sum_score >= 5 && $sum_score <= 7) {
                    echo "แปลผลคะแนนโดยรวม : มีความเครียดปานกลาง";
                } else if ($sum_score >= 8 && $sum_score <= 9) {
                    echo "แปลผลคะแนนโดยรวม : มีความเครียดมาก";
                } else if ($sum_score >= 10 && $sum_score <= 15) {
                    echo "แปลผลคะแนนโดยรวม : มีความเครียดมากที่สุด";
                } else {
                    echo "คะแนนไม่ถูกต้อง";
                }
                ?>
            </p>
        </div>
    </div>
    <div class="button">
        <a href="question.php" class="back">ย้อนกลับ</a>
        <a href="teacher.php?topic_id=<?php echo $topic_id; ?>&sum_score=<?php echo $sum_score; ?>" class="next">หน้าถัดไป</a>
    </div>

</body>

</html>
