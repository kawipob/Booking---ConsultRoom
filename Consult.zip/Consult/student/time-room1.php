<?php
    session_start();
    include 'db_connect.php';
    $conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);

// เช็คการเชื่อมต่อ
if (!$conn) {
    die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
}


if (!isset($_SESSION['user_login'])) {
    header("location: \Consult\login.php"); 
    exit;
}

$user = $_SESSION['user_login'];
if ($user['level'] != 'user') {
    echo '<script>alert("ยินดีต้อนรับนักเรียนทุกคน");window.location="index.php";</script>';
    exit;
}
		// การออกจากระบบ
	if (isset($_GET['logout'])) {
		
		session_unset();
		
		session_destroy();
		
		header("location: \Consult\login.php"); 
		exit;
	}


    $topic_id = '?'; // แทนค่านี้ด้วยค่าจริง
    if(isset($_GET['topic_id'])) {
    $topic_id = $_GET['topic_id'];
    }

    $teacher_id = '?'; // แทนค่านี้ด้วยค่าจริง
    if(isset($_GET['teacher_id'])) {
        $teacher_id = $_GET['teacher_id'];
    }

    $sum_score = '?'; // แทนค่านี้ด้วยค่าจริง
    if(isset($_GET['sum_score'])) {
        $sum_score = $_GET['sum_score'];
    }

?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- ICON LOGO WEB -->
    <link rel="icon" type="image/นามสกุลไฟล์" href="image/satit student.png" />
    <title>แสดงเวลาทั้งหมด</title>
    <!-- CSS -->
    <link rel="stylesheet" href="css/time-room1.css">


  </head>
  <body>
    <!-- navbar -->
    <nav>
        <ul>
            <li><a href="student.php">หน้าหลัก</a></li>
            <li><a href="topic.php">เลือกหัวข้อการปรึกษา</a></li>
            <li><a href="#">การเข้าพบ</a></li>
            <li><a href="history.php">ประวัติการจอง</a></li>
            <li><a href="?logout=true">ออกจากระบบ</a></li>
        </ul>
    </nav>
    <br>

<h2>แสดงตารางเวลาทั้งหมด</h2>

<br>
    <table>
        <thead>
            <tr>
                <th>คาบเรียนที่</th>
                <th>1</th>
                <th>2</th>
                <th>3</th>
                <th>4 (ม.ปลาย)</th>
                <th>4 (ม.ต้น)</th>
                <th>5</th>
                <th>6</th>
                <th>7</th>
                <th>8</th>
            </tr>
            <tr>
                <th>วัน / เวลา </th>
                <th>08.30-09.15</th>
                <th>09.20-10.05</th>
                <th>10.10-10.55</th>
                <th>11.00-11.45</th>
                <th>12.00-12.45</th>
                <th>12.50-13.35</th>
                <th>13.40-14.25</th>
                <th>14.30-15.15</th>
                <th>15.20--16.05</th>
            </tr>
        </thead>
        <?php 
            $query = "SELECT * FROM booking_time ORDER BY id ASC";
            $result = mysqli_query($conn, $query);
            $rows = array();
            while($row = mysqli_fetch_array($result,MYSQLI_ASSOC)) array_push($rows, $row);
        
            function searchArray($arr, $column, $match) {
                foreach ($arr as $row) {
                    if($row[$column] == $match) return $row;
                }
                return null;
            }

            $day = array("จันทร์", "อังคาร", "พุธ", "พฤหัสบดี", "ศุกร์");

            for ($j = 0; $j < 5; $j++) {
                echo "<tr>";
                for ($id = 0; $id < 9 + 1; $id++) {
                    $seq = $id + $j;
                    if ($id === 0) {
                        echo "<td>" . $day[$j] . "</td>";
                        continue;
                    }
            
                    $found = searchArray($rows, "booking_slot", "{$id}:{$j}");
                    if ($found == null) {
                        echo "<td><b style='color:#6a6a6a;'>ไม่ว่าง</b></td>";
                    } else {
                        echo "<td>";
                        if ($found['booking_status'] == 2) {
                            // If status is 2, display 'ไม่ว่าง'
                            echo "<div class='non'>ไม่ว่าง</div>";
            
                        } elseif ($found['booking_status'] == 1) {
                            // If status is 1, display 'จองแล้ว'
                            echo "<div>จองแล้ว</div>";
            
                        } else {
                            // If status is 0, allow booking
                            echo "<button onclick=\"location.href='booking-time.php?id={$found['id']}&act=booking&topic_id={$topic_id}&sum_score={$sum_score}&teacher_id={$teacher_id}'\">ว่าง</button>";
                        }
                        echo "</td>";
                    }
                }
                echo "</tr>";
            }
            


?>
        </tbody>
    </table>

        <div class="button">
            <a href="teacher.php?topic_id=<?php echo $topic_id; ?>&sum_score=<?php echo $sum_score; ?>" class="back">ย้อนกลับ</a>
        </div>
            <br><br><br>
</body>
</html>
ฝาก //
<!-- <script>
    function redirectToEdit(id) {
        // สร้าง URL ที่มีพารามิเตอร์ข้อมูล id เพื่อส่งไปยังหน้า table-time.php
        var url = 'table-time.php?id=' + id;
        // Redirect ไปยังหน้า table-time.php พร้อมส่งพารามิเตอร์
        window.location.href = url;
    }
</script> -->

<!-- echo "<button onclick=\"location.href='booking-time.php?id={$found['id']}&act=booking&topic_id={$topic_id}&sum_score={$sum_score}&teacher_id={$teacher_id}'\">ว่าง</button>"; -->