<?php
    session_start();
    include 'db_connect.php';
    $conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);

  // เช็คการเชื่อมต่อ
  if (!$conn) {
      die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
  }


  if (!isset($_SESSION['user_login'])) {
      header("location: \Consult\login.php"); 
      exit;
  }

  $user = $_SESSION['user_login'];
  if ($user['level'] != 'user') {
      echo '<script>alert("ยินดีต้อนรับนักเรียนทุกคน");window.location="index.php";</script>';
      exit;
  }

		// การออกจากระบบ
	if (isset($_GET['logout'])) {
		
		session_unset();
		
		session_destroy();
		
		header("location: \Consult\login.php"); 
		exit;
	}
    // เวลาที่ต้องการจอง 
    $query = "SELECT * FROM booking_time WHERE id=$_GET[id]";
    $result = mysqli_query($conn, $query);
    $rowbooking = mysqli_fetch_array($result);

    $loggedInUserId = $user['id'];
    $query = "SELECT id, fullname, username FROM users WHERE role = 'user' AND id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $loggedInUserId);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();


    $topic_id = '?'; // แทนค่านี้ด้วยค่าจริง
    if(isset($_GET['topic_id'])) {
    $topic_id = $_GET['topic_id'];
    }

    $teacher_id = '?'; // แทนค่านี้ด้วยค่าจริง
    if(isset($_GET['teacher_id'])) {
        $teacher_id = $_GET['teacher_id'];
    }

    $sum_score = '?'; // แทนค่านี้ด้วยค่าจริง
    if(isset($_GET['sum_score'])) {
        $sum_score = $_GET['sum_score'];
    }

    $query = "SELECT fullname FROM teacher WHERE teacher_id = '$teacher_id'";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $teacher_data = mysqli_fetch_assoc($result);
        $teacher_fullname = $teacher_data['fullname'];
    } else {
        $teacher_fullname = 'Teacher not found'; 
    }

    $query = "SELECT t_topic FROM topic WHERE topic_id = '$topic_id'";

    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $topic_data = mysqli_fetch_assoc($result);
        $topic_t_topic = $topic_data['t_topic'];
    } else {
        $topic_t_topic = 'Topic not found'; 
    }

?>

<!doctype html>
<html lang="en"><!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- ICON LOGO WEB -->
    <link rel="icon" type="image/นามสกุลไฟล์" href="image/welcome.png" />
    <!-- Bootstrap CSS (ห้ามลบ)-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <!-- Title -->
    <title>นักเรียน | คิวที่ต้องการจอง</title>
    <!-- CSS -->
    <link rel="stylesheet" href="css/booking-time.css?v=9999">
    <style>
        
    </style>
</head>
<body>
        <!-- navbar -->
        <nav>
        <ul>
            <li><a href="student.php">หน้าหลัก</a></li>
            <li><a href="topic.php">เลือกหัวข้อการปรึกษา</a></li>
            <li><a href="#">การเข้าพบ</a></li>
            <li><a href="history.php">ประวัติการจอง</a></li>
            <li><a href="?logout=true">ออกจากระบบ</a></li>
        </ul>
    </nav>

    <div class="container">
    <h4>เวลาที่ต้องการจอง</h4>
      <div class="row">
        <div class="col-sm-2 col-md-2"></div>
        <div class="col-12 col-sm-11 col-md-7" style="margin-top: 20px;">
              <hr>

                <div style="margin-left: 15px;">
                  <form action="booking-time_action.php" method="post">

                  <div class="form-group row">
                      <label class="col-sm-5 text-left">รหัสนักเรียน : </label>
                      <div class="col-sm-4">
                        <input type="hidden" id="std_id" name="std_id" required value="<?php echo $row['id']; ?>">
                        <input type="text" name="booking_stdnumber" class="form-control" readonly value="<?php echo $row['username']; ?>";>
                      </div>
                  </div>

                  <div class="form-group row">
                      <label class="col-sm-5 text-left">ชื่อผู้จอง : </label>
                      <div class="col-sm-4">
                        <input type="text" name="booking_name" class="form-control" readonly value="<?php echo $row['fullname']; ?>";>
                      </div>
                  </div>

                  <div class="form-group row">
                      <label class="col-sm-5 text-left">หัวข้อกาปรึกษา : </label>
                      <div class="col-sm-4">
                        <input type="text" name="booking_topic" class="form-control" readonly value="<?php echo $topic_t_topic ?>">
                      </div>
                  </div>

                  <div class="form-group row">
                      <label class="col-sm-5 text-left">คะแนนแบบทดสอบ : </label>
                      <div class="col-sm-4">
                        <input type="text" name="question_score" class="form-control" readonly value="<?php echo $sum_score ?>">
                      </div>
                  </div>

                  <div class="form-group row">
                      <label class="col-sm-5 text-left">อาจารย์ที่ปรึกษา : </label>
                      <div class="col-sm-4">
                        <input type="hidden" id="teacher_id" name="teacher_id" required value="<?php echo $teacher_id; ?>">
                        <input type="text"   class="form-control" name="teacher_fullname"  readonly value="<?php echo $teacher_fullname; ?>">
                      </div>
                  </div>


                  <div class="form-group row">
                      <label class="col-sm-5 text-left">เวลาที่ต้องการจอง : </label>
                      <div class="col-sm-4">
                        <input type="text" name="booking_time" class="form-control"  readonly value="<?php echo $rowbooking['booking_time'];?>">
                      </div>
                  </div>


                    <div class="form-group row">
                      <label class="col-sm-5 text-left">วันที่จอง : </label>
                      <div class="col-sm-4">
                        <input type="date" name="booking_date" class="form-control" readonly value="<?php echo date('Y-m-d');?>" min="<?php echo date('Y-m-d');?>" max="<?php echo date('Y-m-d');?>">
                      </div>
                    </div>

                    <br><br><br>

                      <div class="button">
                        <input type="hidden" name="tbl_id" value="<?php echo $_GET['id'];?>">
                          <a href="time-room1.php?id=<?php echo $rowbooking['id']; ?>" class="back">ย้อนกลับ</a>
                         <button type="submit" class="button-submit" >ยืนยันการจอง</button>
                       <br>
                      </div>
                    
                  </form>

                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </body>
    </html>