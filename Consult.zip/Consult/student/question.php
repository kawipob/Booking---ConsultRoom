<?php 
    session_start();
    include 'db_connect.php';
    $conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);

// เช็คการเชื่อมต่อ
if (!$conn) {
    die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
}


if (!isset($_SESSION['user_login'])) {
    header("location: \Consult\login.php"); 
    exit;
}

$user = $_SESSION['user_login'];
if ($user['level'] != 'user') {
    echo '<script>alert("ยินดีต้อนรับนักเรียนทุกคน");window.location="index.php";</script>';
    exit;
}
		// การออกจากระบบ
	if (isset($_GET['logout'])) {
		
		session_unset();
		
		session_destroy();
		
		header("location: \Consult\login.php"); 
		exit;
	}
    
    //ดึงข้อมูลมาแสดง
    if (isset($_GET['topic_id'])) {
        $topic_id = $_GET['topic_id'];
        $stmt = $conn->prepare("SELECT t_topic FROM topic WHERE topic_id = ?");
        $stmt->bind_param("s", $topic_id);
        $stmt->execute();
        $topicResult = $stmt->get_result();
        $topicData = $topicResult->fetch_assoc();
        $t_topic = $topicData['t_topic'];
    }

    //ดึงข้อมูลมาแสดง
    if (isset($_GET['topic_id'])) {
        $topic_id = $_GET['topic_id'];
        $stmt = $conn->prepare("SELECT refer FROM topic WHERE topic_id = ?");
        $stmt->bind_param("s", $topic_id);
        $stmt->execute();
        $referResult = $stmt->get_result();
        $referData = $referResult->fetch_assoc();
        $refer = $referData['refer'];
    }
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- ICON LOGO WEB -->
    <link rel="icon" type="image/นามสกุลไฟล์" href="image/satit student.png" />
    <title>นักเรียน | แบบทดสอบ</title>
    <!-- CSS -->
    <link rel="stylesheet" href="css/question.css?v=9999">
</head>
<body>
    <!-- navbar -->
    <nav>
        <ul>
            <li><a href="student.php">หน้าหลัก</a></li>
            <li><a href="topic.php">เลือกหัวข้อการปรึกษา</a></li>
            <li><a href="#">การเข้าพบ</a></li>
            <li><a href="history.php">ประวัติการจอง</a></li>
            <li><a href="?logout=true">ออกจากระบบ</a></li>
        </ul>
    </nav>

    <h2>แบบทดสอบ : <?php echo htmlspecialchars($t_topic); ?> </h2>

    <form action="question-score.php?topic_id=<?php echo $topic_id; ?>" method="post">
    <table>
    <thead>
        <tr>
            <th scope="col" style="padding:10px;">ข้อ</th>
            <th scope="col">โจทย์คำถาม</th>
            <th scope="col" width="40%">คำตอบ</th>
        </tr>
    </thead>
    <tbody>
    <?php
        if (isset($_GET['topic_id'])) {
            $topic_id = $_GET['topic_id'];
            $sql = "SELECT * FROM question WHERE topic_id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $topic_id);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows === 0) {
                // No data found, display a message
                echo '<tr><td colspan="3" class="error">" ไม่มีแบบทดสอบ กด ส่งคำตอบได้เลย "</td></tr>';
            } else {
                $i = 1;
                while ($data = $result->fetch_assoc()) {
            ?>
            <tr>
                <th scope="row"><?php echo $i++; ?></th>
                <td><?php echo htmlspecialchars($data['q_question']); ?></td>
                <td style="padding-top:10px;">
                    <label class="form-check-label">
                        <input type="radio" class="form-check-input" required value="0"name="choice[<?php echo $data['no'] ?>]">
                        <?php echo htmlspecialchars($data['choice_a']); ?>
                    </label>

                    <label class="form-check-label">
                        <input type="radio" class="form-check-input" required value="1" name="choice[<?php echo $data['no'] ?>]">
                        <?php echo htmlspecialchars($data['choice_b']); ?>
                    </label>

                <label class="form-check-label">
                    <input type="radio" class="form-check-input" required value="2" name="choice[<?php echo $data['no'] ?>]">
                    <?php echo htmlspecialchars($data['choice_c']); ?>
                </label>

                <label class="form-check-label">
                    <input type="radio" class="form-check-input" required value="3" name="choice[<?php echo $data['no'] ?>]">
                    <?php echo htmlspecialchars($data['choice_d']); ?>
                </label>
                    <br><br>
                </td>
            </tr>
            <?php
        }
    }
}
?>

    </tbody>
</table>

<h4>อ้างอิงข้อมูลจาก : <?php echo htmlspecialchars($refer); ?></h4>

    <br>
    <div class="row">
            <div class="col-md-8" align="center">
                <button 
                type="submit" name="button" onclick="return confirm('คุณต้องการส่งคำตอบหรือไม่');" id="submit" class="btn btn-success">ส่งคำตอบ
                </button>
            </div>
        </div>
    </form>

</body>
</html> 