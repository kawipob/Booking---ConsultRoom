<?php
        session_start();
        include 'db_connect.php';
        $conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);
    
        if (!isset($_SESSION['user_login'])) {
            header("location: /Consult/login.php");
            exit;
        }
        
        $user = $_SESSION['user_login'];
        if ($user['level'] != 'user') {
            echo '<script>alert("ยินดีต้อนรับนักเรียนทุกคน");window.location="index.php";</script>';
            exit;
        }
        
        if (isset($_GET['logout'])) {
            session_unset();
            session_destroy();
            header("location: /Consult/login.php");
            exit;
        }
        
        if (!$conn) {
            die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
        }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- ICON LOGO WEB -->
    <link rel="icon" type="image/นามสกุลไฟล์" href="image/satit student.png" />
    <title>นักเรียน | ประวัติการจอง</title>
    <!-- CSS -->
    <link rel="stylesheet" href="css/history.css">
</head>
<body>    
    <!-- navbar -->
    <nav>
        <ul>
            <li><a href="student.php">หน้าหลัก</a></li>
            <li><a href="topic.php">เลือกหัวข้อการปรึกษา</a></li>
            <li><a href="booking-detail.php">การเข้าพบ</a></li>
            <li><a href="history.php">ประวัติการจอง</a></li>
            <li><a href="?logout=true">ออกจากระบบ</a></li>
        </ul>
    </nav><br>
    <h2>รายการจองทั้งหมด</h2>
    <hr>
    <p>(เรียงรายการ จากล่าสุดไปเก่าสุด)</p>

    <table>
        <thead> 
            <th>หัวข้อการปรึกษา</th>
            <th>คะแนนทำแบบทดสอบ</th>
            <th>อาจารย์ที่ปรึกษา</th>
            <th>เวลาที่จอง</th>
            <th>วันที่จอง</th>
            <th>รีวิว</th>
        </thead>
        <tbody> 
            <?php
                $username = $user['id']; 
                $sql = "SELECT booking_topic, question_score, teacher_fullname, booking_time, booking_date FROM booking WHERE std_id = ? AND cancel_id = 0 ORDER BY booking_date DESC";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("s", $username);
                $stmt->execute();
                $result = $stmt->get_result();
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['booking_topic'] . "</td>";
                        echo "<td>" . $row['question_score'] . "</td>";
                        echo "<td>" . $row['teacher_fullname'] . "</td>";
                        echo "<td>" . $row['booking_time'] . "</td>";
                        echo "<td>" . $row['booking_date'] . "</td>";
                        echo "<td><a class='button' href='reviews.php'>รีวิว</a></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>ไม่พบข้อมูลการจอง</td></tr>";
                }
                $stmt->close();
                $conn->close();
            ?>
        </tbody>
    </table>
</body>
    <script>
        // สคริปต์ JavaScript สำหรับการคลิกปุ่มรีวิว
        const buttons = document.querySelectorAll('.button');
        buttons.forEach(button => {
            button.addEventListener('click', function() {
                this.classList.add('reviewed');
                this.textContent = 'รีวิวแล้ว';
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            $('#bookingTable tbody').html($('#bookingTable tbody tr').sort(function(a, b) {
                return new Date($(b).find('td:eq(3)').text()) - new Date($(a).find('td:eq(3)').text());
            }));
        });
    </script>
</html>

