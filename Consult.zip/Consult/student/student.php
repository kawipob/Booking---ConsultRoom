<?php 
    session_start();
    include 'db_connect.php';
    $conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);

// เช็คการเชื่อมต่อ
if (!$conn) {
    die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
}


if (!isset($_SESSION['user_login'])) { // ถ้าไม่ได้เข้าระบบอยู่
    header("location: \Consult\login.php"); // redirect ไปยังหน้า login.php
    exit;
}

$user = $_SESSION['user_login'];
if ($user['level'] != 'user') {
    echo '<script>alert("ยินดีต้อนรับนักเรียนทุกคน");window.location="index.php";</script>';
    exit;
}
		// การออกจากระบบ
	if (isset($_GET['logout'])) {
		// ลบข้อมูล session ทั้งหมด
		session_unset();
		// ทำลาย session
		session_destroy();
		// Redirect ไปยังหน้าเข้าสู่ระบบหรือหน้าที่ต้องการ
		header("location: \Consult\login.php"); // เปลี่ยนเส้นทางไปยังหน้าที่ต้องการหลังจากออกจากระบบ
		exit;
	}
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- ICON LOGO WEB -->
    <link rel="icon" type="image/นามสกุลไฟล์" href="image/satit student.png" />
    <!-- Bootrap  container -->
    <!-- <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"> -->
    <title>นักเรียน | หน้าหลัก</title>
    <!-- CSS -->
    <link rel="stylesheet" href="css/student.css">
</head>
<body>
    <!-- navbar -->
    <nav>
        <ul>
            <li><a href="student.php">หน้าหลัก</a></li>
            <li><a href="topic.php">เลือกหัวข้อการปรึกษา</a></li>
            <li><a href="#">การเข้าพบ</a></li>
            <li><a href="history.php">ประวัติการจอง</a></li>
            <li><a href="?logout=true">ออกจากระบบ</a></li>
        </ul>
    </nav>
    
        <div class="button-container">
            <div class="row">
                <img src="image/card.png" class="img-fluid" alt="card">
            </div>
        </div> 

    <p class="card-text">โปรดเลือกดูหัวข้อที่ต้องการจะปรึกษา</p>

    <div class="button-container">
        <a href="topic.php" class="button"><span>เลือกหัวข้อการปรึกษา</span></a>
    </div>
    <br><br>

  <div class="container">
  <h2>แบบทดสอบ</h2>
  <hr>
  <div class="row">
    <?php
    $sql = "SELECT * FROM topic";
    $query = $conn->query($sql);

    if ($query->num_rows > 0) {
        while ($row = $query->fetch_assoc()) {
    ?>
    <div class="coll">
      <h3><?php echo $row['t_topic']; ?></h3>
      <p class="text-muted"><?php echo $row['t_detail']; ?></p><br>
      <a class="text" href="question.php?topic_id=<?php echo $row['topic_id']; ?>">ทำแบบทดสอบ</a><br><br>
    </div>
    <?php
        }
    }
    ?>
  </div>
</div>

</body>
<footer>
<div class="dummy_page">
  
</div>
<!-- FOOTER START -->
<div class="footer">
  <div class="contain">
  <div class="col">
    <h1>ระบบสารสนเทศ</h1>
    <ul>
      <li><a href="https://eschool.msu.ac.th/">E-school</a></li>
      <li><a href="https://satit.msu.ac.th/elib/">ห้องสมุดออนไลน์</a></li>
      <li><a href="https://eschool.msu.ac.th/mooc/">ห้องเรียนออนไลน์</a></li>
      <li><a href="https://satit.msu.ac.th/medicinalplants/">สมุนไพรโคกหินลาด</a></li>
      <li><a href="https://eschool.msu.ac.th/checkactivity/">ตรวจสอบชุมนุม/ส่งเสิรม ฯ</a></li>
    </ul>
  </div>
  <div class="col">
    <h1>การเข้าศึกษา</h1>
    <ul>
      <li><a href="https://satit.msu.ac.th/th/about/?about=m1">หลักสูตรที่เปิดสอน</a></li>
      <li><a href="https://eschool.msu.ac.th/admissions/">การสมัครเข้าเรียน</a></li>
      <li><a href="https://satit.msu.ac.th/th/calendar/">ปฏิทิน</a></li>
      <li><a href="https://eschool.msu.ac.th/testbank/">คลังข้อสอบ</a></li>
      <li><a href="https://drive.google.com/drive/u/1/folders/1jzXGCWLrv3SNpxfU_0AqljcnGmhjIjzZ">ข้อสอบ O-NET ม.3,ม.6</a></li>
    </ul>
  </div>
  <div class="col">
    <h1>ระบบการเงิน</h1>
    <ul>
      <li><a href="https://eschool.msu.ac.th/fn/">ระบบการเงิน</a></li>
      <li><a href="https://eschool.msu.ac.th/remission/?TermID=2&AcademicYear=2566&ClassID=0&RoomID=0">ระบบปลดหนี้</a></li>
    </ul>
  </div>
  <div class="col">
    <h1>ข่าว/สื่อสิ่งพิมพ์</h1>
    <ul>
      <li><a href="https://satit.msu.ac.th/th/new/?new=news1">ข่าวเด่น</a></li>
      <li><a href="https://satit.msu.ac.th/th/new/?new=news2">ข่าวกิจกรรม</a></li>
      <li><a href="https://satit.msu.ac.th/th/new/?new=news3">หอเกียรติยศ</a></li>
      <li><a href="https://satit.msu.ac.th/th/new/?new=news4">กิจกรรมการเรียนการสอน</a></li>
      <li><a href="https://satit.msu.ac.th/th/new/?new=news5">งานบริหาร</a></li>
    </ul>
  </div>
  <div class="col">
    <h1>Support</h1>
    <ul>
      <li><a href="https://web.facebook.com/satitmsudemonstration">Facebook</a></li>
      <li><a href="https://satit.msu.ac.th/th/new/">Websitesatitmsu</a></li>
    </ul>
  </div>
  <div class="col social">
    <ul>
        <li><img src="image/Logo.png" alt=""></li>
    </ul>
  </div>
<div class="clearfix"></div>
</div>
</div>
<!-- END OF FOOTER -->
</footer>
</html>