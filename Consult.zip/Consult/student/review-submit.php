<?php
        session_start();
        include 'db_connect.php';
        $conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);
        
        // เช็คการเชื่อมต่อ
        if (!$conn) {
            die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
        }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // ดึงค่าการให้คะแนนจากฟอร์ม
        $teacher_id = $_POST['teacher_id'];
        $std_id = $_POST['std_id'];
        $booking_stdnumber = $_POST['booking_stdnumber'];
        $booking_name = $_POST['booking_name'];
        $booking_topic = $_POST['booking_topic'];
        $rating = $_POST['rating'];

        // โดยปกติคุณจะต้องระบุข้อมูลผู้ใช้หรือ ID เซสชันที่เกี่ยวข้องด้วย

        // เตรียมและทำการ execute คำสั่ง SQL INSERT
        $insert_query = "INSERT INTO review (teacher_id, std_id, booking_stdnumber, booking_name, booking_topic, rating) VALUES ('$teacher_id', '$std_id', '$booking_stdnumber', '$booking_name', '$booking_topic', '$rating')";
        $result = mysqli_query($conn, $insert_query);

        if ($result) {
            echo '<script>alert("รีวิวเรียบร้อย ขอขอบคุณครับ"); window.location.href = "history.php";</script>';
        } else {
            echo "ข้อผิดพลาด: " . mysqli_error($conn);
        }
        
        
    }
?>
