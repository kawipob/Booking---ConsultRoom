<?php
    session_start();
    include 'db_connect.php';
    $conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);
    
    // เช็คการเชื่อมต่อ
    if (!$conn) {
        die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
    }
    
    
    if (!isset($_SESSION['user_login'])) {
        header("location: \Consult\login.php"); 
        exit;
    }
    
    $user = $_SESSION['user_login'];
    if ($user['level'] != 'user') {
        echo '<script>alert("ยินดีต้อนรับนักเรียนทุกคน");window.location="index.php";</script>';
        exit;
    }
            // การออกจากระบบ
        if (isset($_GET['logout'])) {
            
            session_unset();
            
            session_destroy();
            
            header("location: \Consult\login.php"); 
            exit;
        }
    
    $sql = "SELECT * FROM review ORDER BY id DESC"; // ดึงรีวิวเรียงตามวันที่ล่าสุด แก้ไข 'review_date' เป็นชื่อฟิลด์วันที่จริงของคุณ
    $query = mysqli_query($conn, $sql);

// จากนั้นให้ดึงข้อมูลจาก $query และแสดงผลใน HTML ตามที่ต้องการ

?>

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- ICON LOGO WEB -->
    <link rel="icon" type="image/นามสกุลไฟล์" href="image/satit student.png" />
    <title>นักเรียน | รีวิวการให้คำปรึกษา</title>
    <!-- CSS -->
    <link rel="stylesheet" href="css/review.css?v=9999">

    <style>
    </style>


</head>
<body>
    <!-- navbar -->
    <nav>
        <ul>
            <li><a href="student.php">หน้าหลัก</a></li>
            <li><a href="#">เลือกหัวข้อการปรึกษา</a></li>
            <li><a href="#">การเข้าพบ</a></li>
            <li><a href="#">ประวัติการจอง</a></li>
            <li><a href="\Backend\welcome.php">ออกจากระบบ</a></li>
        </ul>
    </nav>

        <div class="container">
            <h2>รีวิวการให้คำปรึกษา</h2><hr>

            <form action="review-submit.php" method="post">
                <?php
                    $username = $user['id'];
                    $sql = "SELECT * FROM booking WHERE std_id = $username ";
                    $result = mysqli_query($conn,$sql);
                     
                    while ($row=mysqli_fetch_array($result)){
                        $teacher_id = $row['teacher_id'];
                        $std_id = $row['std_id'];
                        $booking_stdnumber = $row['booking_stdnumber'];
                        $booking_name = $row['booking_name'];
                        $booking_topic = $row['booking_topic'];
                    }
                ?>
            <div>
                <input type="hidden" id="teacher_id" name="teacher_id" required value="<?php echo $teacher_id; ?>">
                <input type="hidden" id="std_id" name="std_id" required value="<?php echo $std_id; ?>">
                <input type="hidden" id="booking_stdnumber" name="booking_stdnumber" required value="<?php echo $booking_stdnumber; ?>">
                <input type="hidden" id="booking_name" name="booking_name" required value="<?php echo $booking_name; ?>">
                <input type="hidden" id="booking_topic" name="booking_topic" required value="<?php echo $booking_topic; ?>">
            </div><br>

            <div class="rating">
              <input type="radio" id="star5" name="rating" value="5"><label for="star5"></label>
              <input type="radio" id="star4" name="rating" value="4"><label for="star4"></label>
              <input type="radio" id="star3" name="rating" value="3"><label for="star3"></label>
              <input type="radio" id="star2" name="rating" value="2"><label for="star2"></label>
              <input type="radio" id="star1" name="rating" value="1"><label for="star1"></label>
            </div>
            <br><br><br>

            <button type="submit" class="custom-button">ส่งคะแนน</button>

            </form>
</body>
</html>