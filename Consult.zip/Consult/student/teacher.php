<?php
    session_start();
    include 'db_connect.php';
    $conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);

// เช็คการเชื่อมต่อ
if (!$conn) {
    die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
}


if (!isset($_SESSION['user_login'])) {
    header("location: \Consult\login.php"); 
    exit;
}

$user = $_SESSION['user_login'];
if ($user['level'] != 'user') {
    echo '<script>alert("ยินดีต้อนรับนักเรียนทุกคน");window.location="index.php";</script>';
    exit;
}
		// การออกจากระบบ
	if (isset($_GET['logout'])) {
		
		session_unset();
		
		session_destroy();
		
		header("location: \Consult\login.php"); 
		exit;
	}

    $sql = "SELECT * FROM teacher";
    $query = mysqli_query($conn, $sql);

    $topic_id = '?'; // แทนค่านี้ด้วยค่าจริง
    if(isset($_GET['topic_id'])) {
    $topic_id = $_GET['topic_id'];
    }

    $teacher_id = '?'; // แทนค่านี้ด้วยค่าจริง
    if(isset($_GET['teacher_id'])) {
        $teacher_id = $_GET['teacher_id'];
    }

    $sum_score = '?'; // แทนค่านี้ด้วยค่าจริง
    if(isset($_GET['sum_score'])) {
        $sum_score = $_GET['sum_score'];
    }


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- ICON LOGO WEB -->
    <link rel="icon" type="image/นามสกุลไฟล์" href="image/satit student.png" />
    <title>นักเรียน | เลือกอาจารย์ที่ปรึกษา</title>
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <!-- CSS -->
    <link rel="stylesheet" href="css/teacher.css?v=9999">
<style>
</style>
<body>
    <!-- navbar -->
    <nav>
        <ul>
            <li><a href="student.php">หน้าหลัก</a></li>
            <li><a href="topic.php">เลือกหัวข้อการปรึกษา</a></li>
            <li><a href="#">การเข้าพบ</a></li>
            <li><a href="history.php">ประวัติการจอง</a></li>
            <li><a href="\Backend\welcome.php">ออกจากระบบ</a></li>
        </ul>
    </nav>

    <div class="container"><br>
        <h1 class="text-center">อาจารย์ที่ปรึกษา</h1>
        <p class="text-center text-muted">**นักเรียนสามารถเลือกอาจารย์ที่ปรึกษาที่สนใจได้เลย**</p>
        <br><br>
        <div class="row">
            <?php
            while ($row = mysqli_fetch_assoc($query)) {
            ?>
            <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                <div class="profile-card bg-white shadow mb-4 text-center rounded-lg p-4 position-relative h-100">
                    <div class="profile-card_image">
                        <img width='100%' src='../admin/uploads/<?php echo $row['image']; ?>'  class='mb-4 shadow'>
                    </div>

                    <div class="profile-card_details">
                        <h3 class="mb-0"><?php echo $row['fullname']; ?></h3>
                        <p class="text-muted">อาคาร : <?php echo $row['structure']; ?></p>
                        <p class="text-muted"><?php echo $row['room']; ?></p>
                    </div>

                    <div class="profile-card_social text-center p-4">
                    <a href="time-room1.php?teacher_id=<?php echo $row['teacher_id']; ?>&topic_id=<?php echo $topic_id; ?>&sum_score=<?php echo $sum_score; ?>">เลือกอาจารย์ที่ปรึกษา</a>
                    </div>

                </div>
            </div>
            <?php
            }
            ?>
        </div>
    </div>    
</body>
</html>
