<?php session_start(); // เปิดใช้งาน session ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>เข้าสู่ระบบ</title>
    <!-- Bootstrap core CSS -->
    <link href="./css/bootstrap.min.css" rel="stylesheet">
    <!-- <link href="login.css" rel="stylesheet"> -->
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+Thai:wght@300&display=swap');
body {
    background-image: url("image/wall.png");
    background-repeat: no-repeat;
    background-position: center center;
    background-attachment: fixed;
    -o-background-size: 100% 100%, auto;
    -moz-background-size: 100% 100%, auto;
    -webkit-background-size: 100% 100%, auto;
    background-size: 100% 100%, auto;
}
img {
    display: block;
    margin-left: auto;
    margin-right: auto;
    width: 18%;
    margin-top: 10%;
}
.login {
    margin-left: auto;
    margin-right: auto;
    width: 350px;
    height: 220px;
    margin-top: 1%;
    background-color: rgba(0, 2, 16, 0.081);
    padding: 40px 20px 40px 20px;
    border-radius: 15px;
    border: 0.5px solid #4b4b4bb6;
}
.form-control{
    display: block;
    margin: auto;
    width: 250px;
    height: 35px;
    margin-top: 2%;
    border: none;
    border-radius: 5px;
    background-color: #ffff;
    border-color: white;
    padding-left: 15px;
    font-size: 15px;
    font-weight: bold;
    font-family: 'Noto Sans Thai', sans-serif;
}
span {
    color: #555555;
    margin-left: -40%;
    font-size: 12px;
    font-weight: bold;
    font-family: 'Noto Sans Thai', sans-serif;
}
.button{
    display: block;
    margin: auto;
    margin-left: 40%;
    margin-top: 20%;
}
.button-login {
    width: 100px;
    height: 40px;
    background-color: #EBE5FC;
    color: #5b3dae;
    font-family: 'Noto Sans Thai', sans-serif;
    font-weight: bold;
    font-size: 15px;
    border: none;
    border-radius: 10px;
}
.button-login:hover{
    color: #EBE5FC;
    background-color: #5b3dae;

}
.back {
    color: red;
    font-family: 'Noto Sans Thai', sans-serif;
    text-decoration: none;
    font-size: 15px;
    margin-right: 2%;
}
.back:hover{
    color: #5b3dae;
}
.alert-danger {
    color: red;
    margin-top: -5%;
    margin-left: 11%;
    width: 500px;
}

@media screen and (max-width: 460px) {
        img {
            width: 60%;
            margin-left: 16%;
        }
        div.text-center {
            margin-top: 40%;
        }

    }
    </style>
</head>
<body>
<div class="text-center">
    <img src="image/Logo.png" alt="logo"><br>
    <div class="login">
        <form action="login_action.php" method="post">

            <div class="form-group">
                <span>*กรุณากรอกรหัสนักเรียน</span>
                <input type="text" class="form-control" name="username" placeholder="username" aria-describedby="username">
            </div><br>

            <div class="form-group">
                <input type="password" class="form-control" name="password" placeholder="password">
            </div>

            <div class="button">
                 <a href="index.php" class="back">ย้อนกลับ</a> 
                 <button type="submit" name="login" class="button-login">เข้าสู่ระบบ</button>
            </div>

        </form>
    </div>
  </div>
</body>
</html>