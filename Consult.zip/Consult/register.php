<?php session_start(); 
    include 'db_connect.php';
    $conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- ICON LOGO WEB -->
    <link rel="icon" type="image/นามสกุลไฟล์" href="image/satit student.png" />
    <title>สมัครสมาชิก</title>
    <!-- CSS -->
    <link rel="stylesheet" href="register.css">
</head>
<body>

    <img src="image/Logo.png" alt="">
    <?php
        if (isset($_SESSION['message'])) {
            echo '<div class="alert">' . $_SESSION['message'] . '</div>';
            unset($_SESSION['message']);
        }
    ?>
    <div class="login">
        <form action="register_action.php" method="post">

            <div class="form-group">
                <input type="fullname" class="form-control" name="fullname"  placeholder="ชื่อ - นามสกุล " aria-describedby="fullname" required>
            </div><br><br>

            <div class="form-group">
                <input type="username" class="form-control" name="username"  placeholder="รหัสนักเรียน (username)" aria-describedby="username" required>
                <span>*ใส่รหัสนักเรียนให้ถูกต้อง</span>
            </div><br>

            <div class="form-group">
                <input type="password" class="form-control" name="password"  placeholder="รหัสผ่าน" aria-describedby="password" required>
                <span>*รหัสผ่านต้องมีความยาว 5-20 ตัวอักษร</span>
            </div><br>

            <div class="form-group">
                <input type="password" class="form-control" name="c_password" placeholder="ยืนยันรหัสผ่าน" aria-describedby="password" required>
            </div><br><br>

            <div class="form-group">
                <input type="phone" class="form-control" name="phone" placeholder="เบอร์โทรติดต่อ" aria-describedby="phone" required>
            </div>

            <div class="button">
                <a href="index.php" class="back">ย้อนกลับ</a> 
                <button type="submit" name="signup" class="button-signup">สมัครสมาชิก</button>
            </div>
            
        </form>
    </div>
</body>
</html>