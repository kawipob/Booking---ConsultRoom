<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- ICON LOGO WEB -->
    <link rel="icon" type="image/นามสกุลไฟล์" href="image/satit student.png" />
    <title>ยินดีต้อนรับ</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
<div class="text-center">
        <img src="image/Logo.png" alt="logo">

        <div class="welcometext">
            <h1>ยินดีต้อนรับ</h1> 
            <h2>เข้าสู่ห้องพัฒนาสุขภาวะ</h2>
                <img src="image/satit student.png" alt="welcome" class="image">
            <p>ที่พร้อมจะรับฟังแและช่วยเหลือทุกๆ ปัญหาของนักเรียนทุกคน</p>
        </div>
        
        <!-- สมัครสมาชิก เข้าสู่ระบบ -->

        <div class="welcome">
            <a href="register.php">สมัครสมาชิก</a> <a href="login.php" class="login">เข้าสู่ระบบ</a> 
        </div>
        </div>
</body>
</html>