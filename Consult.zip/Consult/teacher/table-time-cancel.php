<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_login']) || $_SESSION['user_login']['level'] !== 'teacher') {
    header("location: \Consult\login.php");
    exit;
}

if (isset($_GET['no'])) {
    $no = $_GET['no'];

    $stmt = $conn->prepare("DELETE FROM booking WHERE no = ?");
    $stmt->bind_param("i", $no);
    $stmt->execute();

    // Close statement and connection
    $stmt->close();
    $conn->close();

    echo '<script>alert("ยกเลิกการจองเรียบร้อยแล้ว");window.location="table-time.php";</script>';
    exit;
} else {
    header("location: \Consult\admin.php");
    exit;
}
?>

