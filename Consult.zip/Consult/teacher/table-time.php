<?php
session_start();
include 'db_connect.php';
$conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);

// เช็คการเชื่อมต่อ
if (!$conn) {
    die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
}


if (!isset($_SESSION['user_login'])) { // ถ้าไม่ได้เข้าระบบอยู่
    header("location: \Consult\login.php"); // redirect ไปยังหน้า login.php
    exit;
}

$user = $_SESSION['user_login'];
if ($user['level'] != 'teacher') {
    echo '<script>alert("สำหรับผู้ดูแลระบบเท่านั้น");window.location="index.php";</script>';
    exit;
}
		// การออกจากระบบ
	if (isset($_GET['logout'])) {
		// ลบข้อมูล session ทั้งหมด
		session_unset();
		// ทำลาย session
		session_destroy();
		// Redirect ไปยังหน้าเข้าสู่ระบบหรือหน้าที่ต้องการ
		header("location: \Consult\login.php"); // เปลี่ยนเส้นทางไปยังหน้าที่ต้องการหลังจากออกจากระบบ
		exit;
	}
?>

<!DOCTYPE html>
<html>
<head>
    <!-- ICON LOGO WEB -->
    <link rel="icon" type="image/นามสกุลไฟล์" href="image/satit student.png" />
    <!-- iCons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <title>อาจารย์ | หน้าแก้ไขตารางเวลา</title>
    <!-- ใส่ CSS -->
    <link rel="stylesheet" href="css/table-time.css?v=9999">
</head>
<body>
<header>
    <h2>แก้ไขตารางเวลา</h2>
    <h4>ยินดีต้อนรับ อาจารย์ <?php echo $user['fullname']; ?></h4>
</header>


<div class="sidebar">
    <h2>DMSU Consult Room</h2>
    <a href="teacher.php"><i class="fas fa-home"></i> แดชบอร์ด</a>
    <a href="table-time-app.php"><i class="fas fa-calendar-alt"></i> ตารางนัดหมาย</a>
    <a href="table-time.php"><i class="far fa-calendar-alt"></i> แก้ไขตารางเวลา</a>
    <a href="table-score.php"><i class="fas fa-poll"></i> คะแนน ทำแบบทดสอบ</a>
    <a href="table-review.php"><i class="fas fa-poll"></i> คะแนน การรีวิว</a>
    <a href="teacher-profile.php"><i class="fas fa-user"></i> โปรไฟล์</a>
    <a href="?logout=true"><i class="fas fa-sign-out-alt"></i> ออกจากระบบ</a>
</div>

<div class="content">
    <h3>แสดงตารางเวลา</h3>
<table>
        <thead>
            <tr>
                <th>คาบที่</th>
                <th>1</th>
                <th>2</th>
                <th>3</th>
                <th>4 (ม.ปลาย)</th>
                <th>4 (ม.ต้น)</th>
                <th>5</th>
                <th>6</th>
                <th>7</th>
                <th>8</th>
            </tr>
            <tr>
                <th>วัน / เวลา </th>
                <th>08.30-09.15</th>
                <th>09.20-10.05</th>
                <th>10.10-10.55</th>
                <th>11.00-11.45</th>
                <th>12.00-12.45</th>
                <th>12.50-13.35</th>
                <th>13.40-14.25</th>
                <th>14.30-15.15</th>
                <th>15.20-16.05</th>
            </tr>
        </thead>
        <?php 
            $query = "SELECT * FROM booking_time ORDER BY id ASC";
            $result = mysqli_query($conn, $query);
            $rows = array();
            while($row = mysqli_fetch_array($result,MYSQLI_ASSOC)) array_push($rows, $row);
        
            function searchArray($arr, $column, $match) {
                foreach ($arr as $row) {
                    if($row[$column] == $match) return $row;
                }
                return null;
            }

            $day = array("จันทร์", "อังคาร", "พุธ", "พฤหัสบดี", "ศุกร์");

            for ($j = 0; $j < 5; $j++) {
                echo "<tr>";
                for ($id = 0; $id < 9 + 1; $id++) {
                    $seq = $id + $j;
                    if ($id === 0) {
                        echo "<td>" . $day[$j] . "</td>";
                        continue;
                    }
            
                    $found = searchArray($rows, "booking_slot", "{$id}:{$j}");
                    if ($found == null) {
                        echo "<td><b style='color:#6a6a6a;'>ไม่ว่าง</b></td>";
                    } else {
                        echo "<td>";
                        if ($found['booking_status'] == 2) {
                            echo "<div class='non'>ไม่ว่าง</div>";
            
                        } elseif ($found['booking_status'] == 1) {
                            echo "<div>จองแล้ว</div>";
            
                        } else {
                            echo "<button onclick=\"location.href='#'\">ว่าง</button>";
                        }
                        echo "</td>";
                    }
                }
                echo "</tr>";
            }
            


?>
        </tbody>
    </table>
</div><br><br>

<div class="content">
    <h3>แก้ไขตารางเวลา</h3>
    <!-- ตารางแก้ไข -->
    <table>
        <thead>
                <tr>
                    <th>คาบที่</th>
                    <th>1</th>
                    <th>2</th>
                    <th>3</th>
                    <th>4 (ม.ปลาย)</th>
                    <th>4 (ม.ต้น)</th>
                    <th>5</th>
                    <th>6</th>
                    <th>7</th>
                    <th>8</th>
                </tr>
                <tr>
                    <th>วัน / เวลา </th>
                    <th>08.30-09.15</th>
                    <th>09.20-10.05</th>
                    <th>10.10-10.55</th>
                    <th>11.00-11.45</th>
                    <th>12.00-12.45</th>
                    <th>12.50-13.35</th>
                    <th>13.40-14.25</th>
                    <th>14.30-15.15</th>
                    <th>15.20--16.05</th>
                </tr>
            </thead>
        <tbody>
        <?php 
            $day = array("จันทร์", "อังคาร", "พุธ", "พฤหัสบดี", "ศุกร์");

            for ($j = 0; $j < 5; $j++) {
                echo "<tr>";
                echo "<td>" . $day[$j] . "</td>";

                for ($id = 1; $id < 9 + 1; $id++) { 
                    $found = searchArray($rows, "booking_slot", "{$id}:{$j}");

                    echo "<td>";

                    if ($found !== null && isset($found['booking_status'])) {
                        if ($found['booking_status'] == 0 || $found['booking_status'] == 1) {
                            echo "<button class='edit' onclick=\"location.href='table-time-edit.php?id={$found['id']}'\">แก้ไข</button>";
                        } elseif ($found['booking_status'] == 2) {
                            echo "<button class='edit' onclick=\"location.href='table-time-edit.php?id={$found['id']}'\">แก้ไข</button>";
                        }

                    }

                    echo "</td>";
                }
                echo "</tr>";
            }
    ?>
        </tbody>
    </table>
</div>
<br><br>
</body>     
</html>
