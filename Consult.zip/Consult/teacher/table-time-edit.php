<?php
session_start();
include 'db_connect.php';
$conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);

// เช็คการเชื่อมต่อ
if (!$conn) {
    die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
}


if (!isset($_SESSION['user_login'])) { // ถ้าไม่ได้เข้าระบบอยู่
    header("location: \Consult\login.php"); // redirect ไปยังหน้า login.php
    exit;
}

$user = $_SESSION['user_login'];
if ($user['level'] != 'teacher') {
    echo '<script>alert("สำหรับผู้ดูแลระบบเท่านั้น");window.location="index.php";</script>';
    exit;
}
		// การออกจากระบบ
	if (isset($_GET['logout'])) {
		// ลบข้อมูล session ทั้งหมด
		session_unset();
		// ทำลาย session
		session_destroy();
		// Redirect ไปยังหน้าเข้าสู่ระบบหรือหน้าที่ต้องการ
		header("location: \Consult\login.php"); // เปลี่ยนเส้นทางไปยังหน้าที่ต้องการหลังจากออกจากระบบ
		exit;
	}
    
?>

<!DOCTYPE html>
<html>
<head>
    <!-- ICON LOGO WEB -->
    <link rel="icon" type="image/นามสกุลไฟล์" href="image/satit student.png" />
    <!-- iCons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <title>อาจารย์ | หน้าแก้ไขตารางเวลา</title>
    <!-- CSS-->
    <link rel="stylesheet" href="css/table-time-edit.css?v=9999">
</head>
<body>
<header>
    <h2>แก้ไขตารางเวลา</h2>
    <h4>ยินดีต้อนรับอาจารย์ <?php echo $user['fullname']; ?></h4>
</header>

<!-- เริ่มต้นส่วนของ sidebar -->
<div class="sidebar">
    <h2>DMSU Consult Room</h2>
    <a href="teacher.php"><i class="fas fa-home"></i> แดชบอร์ด</a>
    <a href="table-time-app.php"><i class="fas fa-calendar-alt"></i> ตารางนัดหมาย</a>
    <a href="table-time.php"><i class="far fa-calendar-alt"></i> แก้ไขตารางเวลา</a>
    <a href="table-score.php"><i class="fas fa-poll"></i> คะแนน ทำแบบทดสอบ</a>
    <a href="table-review.php"><i class="fas fa-poll"></i> คะแนน การรีวิว</a>
    <a href="teacher-profile.php"><i class="fas fa-user"></i> โปรไฟล์</a>
    <a href="?logout=true"><i class="fas fa-sign-out-alt"></i> ออกจากระบบ</a>
</div>

<br><br>
<div class="content">
    <?php
            $id = $_GET['id'];
            $sql = "SELECT * FROM booking_time WHERE id = $id";
            $result = mysqli_query($conn,$sql);
     
             while ($row=mysqli_fetch_array($result)){
                $booking_day = $row['booking_day'];
                $booking_time = $row['booking_time'];
             }
    ?>
    <form action="table-time-edit-save.php" method="post">
        
        <input type="hidden" id="id" name="id" value="<?php echo $id ?>">


        <div class="mb-3">
            <label for="booking_day" class="form-label">วัน : </label><br>
            <input type="text" class="form-control" id="booking_day" name="booking_day" disabled placeholder="<?php echo $booking_day ?>">
        </div><br>

        <div class="mb-3">
            <label for="booking_time" class="form-label">เวลา : </label><br>
            <input type="text" class="form-control" id="booking_time" name="booking_time" disabled placeholder="<?php echo $booking_time ?>">
        </div><br>

        <div class="mb-3">
            <label for="booking_status" class="form-label">สถานะ : </label><br>
            <select id="booking_status" name="booking_status" class="form-select">
                <option id="0" value="0">ว่าง</option>
                <option id="1" value="1">ไม่ว่าง</option>
                <option id="2" value="2">ไม่สามารถจองได้</option>
            </select>
        </div><br>
        <input type="submit" value="บันทึก"> <a href="table-time.php" class="back">ย้อนกลับ</a>
    </form>
</div>
</body>     
</html>
