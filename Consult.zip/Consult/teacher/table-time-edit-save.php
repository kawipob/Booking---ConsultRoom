<?php
session_start();
include 'db_connect.php';
$conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);

if (!$conn) {
    die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if(isset($_POST['id'])) { // ตรวจสอบว่ามีค่า 'id' ที่ถูกส่งมาหรือไม่
        $id = $_POST['id']; // รับค่า ID ที่ถูกส่งมาจากฟอร์ม
        $booking_status = $_POST['booking_status']; // รับค่าสถานะที่แก้ไขจากฟอร์ม

        // ทำการปรับปรุงข้อมูลในฐานข้อมูล
        $sql = "UPDATE booking_time SET booking_status = '$booking_status' WHERE id = $id";

        if (mysqli_query($conn, $sql)) {
            echo '<script>alert("แก้ไขตารางเวลาเรียบร้อยแล้ว");window.location="table-time.php";</script>';
        } else {
            echo "เกิดข้อผิดพลาดในการบันทึกข้อมูล: " . mysqli_error($conn);
        }
    } else {
        echo "ไม่พบ 'id' ที่ถูกส่งมา";
    }
}

mysqli_close($conn);
?>
