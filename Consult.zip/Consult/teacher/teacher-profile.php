<?php
session_start();
include 'db_connect.php';
$conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);

// เช็คการเชื่อมต่อ
if (!$conn) {
    die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
}


if (!isset($_SESSION['user_login'])) { // ถ้าไม่ได้เข้าระบบอยู่
    header("location: \Consult\login.php"); // redirect ไปยังหน้า login.php
    exit;
}

$user = $_SESSION['user_login'];
if ($user['level'] != 'teacher') {
    echo '<script>alert("สำหรับอาจารย์เท่านั้น");window.location="index.php";</script>';
    exit;
}
		// การออกจากระบบ
	if (isset($_GET['logout'])) {
		// ลบข้อมูล session ทั้งหมด
		session_unset();
		// ทำลาย session
		session_destroy();
		// Redirect ไปยังหน้าเข้าสู่ระบบหรือหน้าที่ต้องการ
		header("location: \Consult\login.php"); // เปลี่ยนเส้นทางไปยังหน้าที่ต้องการหลังจากออกจากระบบ
		exit;
	}
?>

<!DOCTYPE html>
<html>
<head>
    <!-- ICON LOGO WEB -->
    <link rel="icon" type="image/นามสกุลไฟล์" href="image/satit student.png" />
    <!-- iCons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <title>อาจารย์ | โปรไฟล์</title>
    <!-- CSS -->
    <link rel="stylesheet" href="css/teacher-profile.css?v=9999">
</head>
<body>
<header>
    <h2>โปรไฟล์</h2>
    <h4>ยินดีต้อนรับ อาจารย์ <?php echo $user['fullname']; ?></h4>
</header>

<!-- เริ่มต้นส่วนของ sidebar -->
<div class="sidebar">
    <h2>DMSU Consult Room</h2>
    <!-- แยกลิงก์แต่ละบรรทัด -->
    <a href="teacher.php"><i class="fas fa-home"></i> แดชบอร์ด</a>
    <a href="table-time-app.php"><i class="fas fa-calendar-alt"></i> ตารางนัดหมาย</a>
    <a href="table-time.php"><i class="far fa-calendar-alt"></i> แก้ไขตารางเวลา</a>
    <a href="table-score.php"><i class="fas fa-poll"></i> คะแนน ทำแบบทดสอบ</a>
    <a href="table-review.php"><i class="fas fa-poll"></i> คะแนน การรีวิว</a>
    <a href="teacher-profile.php"><i class="fas fa-user"></i> โปรไฟล์</a>
    <a href="?logout=true"><i class="fas fa-sign-out-alt"></i> ออกจากระบบ</a>
</div>

<div class="content">
    <table border="1">
        <thead>
            <tr>
                <th style="width: 15%;">ชื่อ</th>
                <th style="width: 13%;">บัญชีผู้ใช้งาน</th>
                <th style="width: 13%;">อีเมลล์</th>
                <th style="width: 13%;">เบอร์โทรติดต่อ</th>
                <th style="width: 13%;">อาคาร</th>
                <th style="width: 13%;">ห้อง</th>
                <th style="width: 13%;">รูปโปรไฟล์</th>
                <th style="width: 5%;">แก้ไข</th>
                <th style="width: 5%;">ลบ</th>
            </tr>
        </thead>
        <tbody>
        <?php
            // ดึงข้อมูล admin ที่เข้าสู่ระบบอยู่
            $loggedInUserId = $user['id'];
            $query = "SELECT * FROM teacher WHERE role = 'teacher' AND teacher_id = $loggedInUserId";
            $result = $conn->query($query);
 
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row['fullname'] . "</td>";
                    echo "<td>" . $row['username'] . "</td>";
                    echo "<td>" . $row['email'] . "</td>";
                    echo "<td>" . $row['phone'] . "</td>";
                    echo "<td>" . $row['structure'] . "</td>";
                    echo "<td>" . $row['room'] . "</td>";
                    echo "<td><img width='100%' src='../admin/uploads/" . $row['image'] . "' alt=''></td>";
                    echo "<td><a href='teacher-profile-edit.php?teacher_id=" . $row['teacher_id'] . "' class='button-edit'><button><i class='fas fa-edit'></i></button></a></td>";
                    echo "<td><a href='teacher-softdelete_action.php?teacher_id=" . $row['teacher_id'] . "' class='button-delete'><button><i class='fas fa-trash-alt'></i></button></a></td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='5'>ไม่พบผู้ใช้งานที่ค้นหา</td></tr>";
            }
            ?>



        </tbody>
    </table>
</div>

</body>     
</html>
