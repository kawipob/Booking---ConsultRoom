<?php
session_start();
include 'db_connect.php';
$conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);

// เช็คการเชื่อมต่อ
if (!$conn) {
    die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
}


if (!isset($_SESSION['user_login'])) { // ถ้าไม่ได้เข้าระบบอยู่
    header("location: \Consult\login.php"); // redirect ไปยังหน้า login.php
    exit;
}

$user = $_SESSION['user_login'];
if ($user['level'] != 'teacher') {
    echo '<script>alert("สำหรับผู้ดูแลระบบเท่านั้น");window.location="index.php";</script>';
    exit;
}
		// การออกจากระบบ
	if (isset($_GET['logout'])) {
		// ลบข้อมูล session ทั้งหมด
		session_unset();
		// ทำลาย session
		session_destroy();
		// Redirect ไปยังหน้าเข้าสู่ระบบหรือหน้าที่ต้องการ
		header("location: \Consult\login.php"); // เปลี่ยนเส้นทางไปยังหน้าที่ต้องการหลังจากออกจากระบบ
		exit;
	}
// ดึงข้อมูลการจอง เเละ แสดงคะแนนการทำแบบทดสอบ
// $query = "SELECT * FROM booking";
// $result = $conn->query($query);
?>

<!DOCTYPE html>
<html>
<head>
    <!-- ICON LOGO WEB -->
    <link rel="icon" type="image/นามสกุลไฟล์" href="image/satit student.png" />
    <!-- iCons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <title>อาจารย์ | คะแนนทำ แบบทดสอบ</title>
    <!-- CSS -->
    <link rel="stylesheet" href="css/table-score.css">
</head>
<body>
<header>
    <h2>คะแนน ทำแบบทดสอบ</h2>
    <h4>ยินดีต้อนรับ อาจารย์ <?php echo $user['fullname']; ?></h4>
</header>

<!-- เริ่มต้นส่วนของ sidebar -->
<div class="sidebar">
    <h2>DMSU Consult Room</h2>
    <!-- แยกลิงก์แต่ละบรรทัด -->
    <a href="teacher.php"><i class="fas fa-home"></i> แดชบอร์ด</a>
    <a href="table-time-app.php"><i class="fas fa-calendar-alt"></i> ตารางนัดหมาย</a>
    <a href="table-time.php"><i class="far fa-calendar-alt"></i> แก้ไขตารางเวลา</a>
    <a href="table-score.php"><i class="fas fa-poll"></i> คะแนน ทำแบบทดสอบ</a>
    <a href="table-review.php"><i class="fas fa-poll"></i> คะแนน การรีวิว</a>
    <a href="teacher-profile.php"><i class="fas fa-user"></i> โปรไฟล์</a>
    <a href="?logout=true"><i class="fas fa-sign-out-alt"></i> ออกจากระบบ</a>
</div>
<div class="content">
    <form method="GET" action="">
        <input type="text" name="search" placeholder="ค้นหา">
        <input type="submit" value="ค้นหา">
    </form> <br>

<table>
    <thead>
        <tr>
            <th>ลำดับ</th>
            <th>รหัสนักเรียน</th>
            <th>ชื่อผู้ใช้งาน</th>
            <th>หัวข้อการปรึกษา</th>
            <th>คะแนนทำแบบทดสอบ</th>
        </tr>
    </thead>
    <tbody>
    <?php
        // ค้นหา
        $query = "SELECT * FROM booking ";
        $result = mysqli_query($conn, $query);

        if (isset($_GET['search'])) {
            $search = $_GET['search'];
            $sql = "SELECT * FROM booking WHERE booking_topic LIKE '%$search%' OR question_score LIKE '%$search%'";
            $result = mysqli_query($conn, $query);

            if (!$result) {
                die("เกิดข้อผิดพลาดในการค้นหา: " . mysqli_error($conn));
            }
        }

        $count = 1;
        $username = $user['id'];
        $sql = "SELECT booking_stdnumber, booking_name, booking_topic, question_score,  booking_time, booking_date FROM booking WHERE teacher_id = ? ";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $username);
        // สั่งรันคำสั่ง SQL
        $stmt->execute();
        // เก็บผลลัพธ์
        $result = $stmt->get_result();

        // ตรวจสอบผลลัพธ์
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $count . "</td>";
                echo "<td>" . $row['booking_stdnumber'] . "</td>";
                echo "<td>" . $row['booking_name'] . "</td>";
                echo "<td>" . $row['booking_topic'] . "</td>";
                echo "<td>" . $row['question_score'] . "</td>";
                echo "</tr>";
                $count++;
            }
        } else {
            echo "<tr><td colspan='5'>ไม่พบข้อมูลที่ค้นหา</td></tr>";
        }
    ?>
    </tbody>
</table>
</div><br>
<div class="score"><br>
    <h4>0 - 4 คะแนน : ความเสี่ยงน้อย | 5 - 7 คะแนน : ความเสี่ยงปานกลาง | 8 - 9 คะแนน : ความเสี่ยงมาก | 10 - 15 คะแนน : ความเสี่ยงมากที่สุด</h4><br>
</div>
</body>     
</html>
