<?php
session_start();
include 'db_connect.php';
$conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);

// เช็คการเชื่อมต่อ
if (!$conn) {
    die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
}

if (!isset($_SESSION['user_login'])) { // ถ้าไม่ได้เข้าระบบอยู่
    header("location: \Consult\login.php"); // redirect ไปยังหน้า login.php
    exit;
}

$user = $_SESSION['user_login'];
if ($user['level'] != 'teacher') {
    echo '<script>alert("สำหรับผู้ดูแลระบบเท่านั้น");window.location="index.php";</script>';
    exit;
}

    // การออกจากระบบ
if (isset($_GET['logout'])) {
    // ลบข้อมูล session ทั้งหมด
	session_unset();
	// ทำลาย session
	session_destroy();
	// Redirect ไปยังหน้าเข้าสู่ระบบหรือหน้าที่ต้องการ
	header("location: \Consult\login.php"); // เปลี่ยนเส้นทางไปยังหน้าที่ต้องการหลังจากออกจากระบบ
	exit;
}
    
    // คำสั่ง SQL เพื่อดึงข้อมูลจากตารางที่เก็บข้อมูลผู้ใช้งาน
$sql = "SELECT COUNT(*) AS total_users FROM users WHERE role = 'user' ";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $totalUsers = $row["total_users"];
    }
} else {
    $totalUsers = 0;
}

// แสดงรายการจองเดือนนี้
$username = $user['id'];
$month_start = date("Y-m-01");
$month_end = date("Y-m-t");
$sql = "SELECT COUNT(*) AS total_bookings FROM booking WHERE teacher_id = ? AND booking_date BETWEEN ? AND ?";
$stmt = $conn->prepare($sql);
if ($stmt) {
    $stmt->bind_param("iss", $username, $month_start, $month_end);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result) {
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $total_bookings = $row["total_bookings"];
        } else {
            $total_bookings = 0;
        }
        $result->close();
    } else {
        // Handle query execution error
        $total_bookings = 0;
    }
    $stmt->close();
} else {
    // Handle SQL preparation error
    $total_bookings = 0;
}
// แสดงรายการค้นหา
$query = "SELECT * FROM users WHERE role = 'user'";
$result = mysqli_query($conn, $query);

if (isset($_GET['search'])) {
    $search = $_GET['search'];
    // คำสั่ง SQL เพื่อค้นหาผู้ใช้งานที่ตรงกับชื่อที่ค้นหา
    $query = "SELECT * FROM users WHERE role = 'user' AND (username LIKE '%$search%' OR fullname LIKE '%$search%')";
    $result = mysqli_query($conn, $query);

    if (!$result) {
        die("เกิดข้อผิดพลาดในการค้นหา: " . mysqli_error($conn));
    }
}


?>

<!DOCTYPE html>
<html>
<head>
    <!-- ICON LOGO WEB -->
    <link rel="icon" type="image/นามสกุลไฟล์" href="image/satit student.png" />
    <!-- iCons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <title>อาจารย์ | หน้าแดชบอร์ด</title>
    <!-- CSS-->
    <link rel="stylesheet" href="css/teacher.css?v=9999">

</head>
<body>
<header>
    <h2>แดชบอร์ด</h2>
    <h4>ยินดีต้อนรับ อาจารย์ <?php echo $user['fullname']; ?></h4>
</header>

<!-- เริ่มต้นส่วนของ sidebar -->
<div class="sidebar">
    <h2>DMSU Consult Room</h2>
    <!-- แยกลิงก์แต่ละบรรทัด -->
    <a href="teacher.php"><i class="fas fa-home"></i> แดชบอร์ด</a>
    <a href="table-time-app.php"><i class="fas fa-calendar-alt"></i> ตารางนัดหมาย</a>
    <a href="table-time.php"><i class="far fa-calendar-alt"></i> แก้ไขตารางเวลา</a>
    <a href="table-score.php"><i class="fas fa-poll"></i> คะแนน ทำแบบทดสอบ</a>
    <a href="table-review.php"><i class="fas fa-poll"></i> คะแนน การรีวิว</a>
    <a href="teacher-profile.php"><i class="fas fa-user"></i> โปรไฟล์</a>
    <a href="?logout=true"><i class="fas fa-sign-out-alt"></i> ออกจากระบบ</a>
</div>

<!-- เริ่มต้นส่วนของ content หลัก -->
<div class="content">
    <!-- ส่วนของแดชบอร์ด -->
    <div class="dashboard-info">
        <div>
        <?php 
            // หาวันที่เริ่มต้นและสิ้นสุดของวันนี้
            $startOfDay = date("Y-m-d 00:00:00");
            $endOfDay = date("Y-m-d 23:59:59");

            // ทำการ query เพื่อหาจำนวนการจองที่ถูกสร้างในวันนี้
            $query = "SELECT COUNT(*) as totalBookings FROM booking WHERE booking_create BETWEEN ? AND ? AND teacher_id = ?";
            $stmt = mysqli_prepare($conn, $query);

            if ($stmt) {
                mysqli_stmt_bind_param($stmt, 'ssi', $startOfDay, $endOfDay, $user['id']);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_store_result($stmt);
                if (mysqli_stmt_num_rows($stmt) > 0) {
                    mysqli_stmt_bind_result($stmt, $totalBookings);
                    mysqli_stmt_fetch($stmt);
                } else {
                    $totalBookings = 0;
                }
                mysqli_stmt_close($stmt);
            } else {
                $totalBookings = 0;
            }
        ?>
            <h2><?php echo $totalBookings; ?></h2>
            <p>จำนวนการจองวันนี้</p>
        </div>

        <div>
        <?php 
                $query = "SELECT COUNT(*) as total_reviews FROM booking WHERE teacher_id = ?";
                $stmt = mysqli_prepare($conn, $query);

                if ($stmt) {
                    mysqli_stmt_bind_param($stmt, 'i', $user['id']);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_store_result($stmt);
                    if (mysqli_stmt_num_rows($stmt) > 0) {
                        mysqli_stmt_bind_result($stmt, $totalBooking);
                        mysqli_stmt_fetch($stmt);
                    } else {
                        $totalBooking = 0;
                    }
                    mysqli_stmt_close($stmt);
                } else {
                    $totalBooking = 0;
                }

            ?>
            <h2><?php echo $totalBooking; ?></h2>
            <p>จำนวนการจองทั้งหมด</p>
        </div>

        <div>
            <?php 
                $query = "SELECT COUNT(*) as total_reviews FROM review WHERE teacher_id = ?";
                $stmt = mysqli_prepare($conn, $query);
                if ($stmt) {
                    mysqli_stmt_bind_param($stmt, 'i', $user['id']);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_store_result($stmt);
                    if (mysqli_stmt_num_rows($stmt) > 0) {
                        mysqli_stmt_bind_result($stmt, $totalReviews);
                        mysqli_stmt_fetch($stmt);
                    } else {
                        $totalReviews = 0;
                    }
                    mysqli_stmt_close($stmt);
                } else {
                    $totalReviews = 0;
                }
            ?>
            <h2><?php echo $totalReviews; ?></h2>
            <p>จำนวนการรีวิว</p>
        </div>

        <div>
            <h2><?php echo $totalUsers; ?></h2>
            <p>ผู้ใช้งานทั้งหมด</p>
        </div>

    </div>
</div><br><br>

<div class="datacontent">
    <h3>ผู้ใช้งานทั้งหมด</h3>

    <form method="GET" action="">
        <input type="text" name="search" placeholder="ค้นหาชื่อผู้ใช้งาน">
        <input type="submit" value="ค้นหา">
    </form>

    <br>
    <table border="1">
    <thead>
        <tr>
            <th>ลำดับ</th>
            <th>รหัสนักเรียน</th>
            <th>ชื่อผู้ใช้งาน</th>
        </tr>
    </thead>
    <tbody>
    <?php
        $count = 1;
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $count . "</td>";
                echo "<td>" . $row['username'] . "</td>";
                echo "<td>" . $row['fullname'] . "</td>";
                echo "</tr>";
                $count++;
            }
        } else {
            echo "<tr><td colspan='3'>ไม่พบผู้ใช้งานที่ค้นหา</td></tr>";
        }
    ?>
    </tbody>
</table>

</div>

</body>     
</html>
