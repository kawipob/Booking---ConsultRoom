<?php
    // เชื่อมต่อกับฐานข้อมูล
    include 'db_connect.php';
    $conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);

    // ตรวจสอบการเชื่อมต่อ
    if (!$conn) {
        die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
    }

    $teacher_id = $_POST['teacher_id'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = md5($_POST['password']); // Encrypting with md5 - consider more secure options
    $fullname = $_POST['fullname'];
    $phone = $_POST['phone'];
    $structure = $_POST['structure'];
    $room = $_POST['room'];
    $profile = $_POST['profile'];
    $deleted_id = $_POST['deleted_id'];
    
    // Update query for the 'teacher' table
    $sql = "UPDATE teacher SET email=?, username=?, password=?, fullname=?, phone=?, structure=?, room=?, profile=?, deleted_id=? WHERE teacher_id=?";
    $stmt = mysqli_prepare($conn, $sql);
    
    // Check if the prepare() call succeeded
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'sssssssssi', $email, $username, $password, $fullname, $phone, $structure, $room, $profile, $deleted_id, $teacher_id);
    
        $result = mysqli_stmt_execute($stmt);
        
        if ($result) {
            echo '<script>alert("แก้ไขข้อมูลเรียบร้อยแล้ว");window.location="teacher-profile.php";</script>';
            exit();
        } else {
            echo "เกิดข้อผิดพลาดในการอัปเดตข้อมูล: " . mysqli_stmt_error($stmt);
        }
    } else {
        echo "เกิดข้อผิดพลาดในการเตรียมคำสั่ง SQL: " . mysqli_error($conn);
    }
    
    mysqli_stmt_close($stmt);
    mysqli_close($conn);
?>
