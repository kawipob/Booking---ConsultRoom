<?php
session_start();
include 'db_connect.php';
$conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);

// เช็คการเชื่อมต่อ
if (!$conn) {
    die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
}


if (!isset($_SESSION['user_login'])) { // ถ้าไม่ได้เข้าระบบอยู่
    header("location: \Consult\login.php"); // redirect ไปยังหน้า login.php
    exit;
}

$user = $_SESSION['user_login'];
if ($user['level'] != 'teacher') {
    echo '<script>alert("สำหรับอาจารย์เท่านั้น");window.location="index.php";</script>';
    exit;
}
		// การออกจากระบบ
	if (isset($_GET['logout'])) {
		// ลบข้อมูล session ทั้งหมด
		session_unset();
		// ทำลาย session
		session_destroy();
		// Redirect ไปยังหน้าเข้าสู่ระบบหรือหน้าที่ต้องการ
		header("location: \Consult\login.php"); // เปลี่ยนเส้นทางไปยังหน้าที่ต้องการหลังจากออกจากระบบ
		exit;
	}
?>

<!DOCTYPE html>
<html>
<head>
    <!-- ICON LOGO WEB -->
    <link rel="icon" type="image/นามสกุลไฟล์" href="image/satit student.png" />
    <!-- iCons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <title>แอดมิน | หน้าแดชบอร์ด</title>
    <!-- CSS -->
    <link rel="stylesheet" href="css/teacher-profile-edit.css?v=9999">

    </style>
</head>
<body>
<header>
    <h2>แก้ไข โปรไฟล์</h2>
    <h4>ยินดีต้อนรับ <?php echo $user['fullname']; ?></h4>
</header>

<!-- เริ่มต้นส่วนของ sidebar -->
<div class="sidebar">
    <h2>DMSU Consult Room</h2>
    <a href="teacher.php"><i class="fas fa-home"></i> แดชบอร์ด</a>
    <a href="table-time-app.php"><i class="fas fa-calendar-alt"></i> ตารางนัดหมาย</a>
    <a href="table-time.php"><i class="far fa-calendar-alt"></i> แก้ไขตารางเวลา</a>
    <a href="table-score.php"><i class="fas fa-poll"></i> คะแนน ทำแบบทดสอบ</a>
    <a href="table-review.php"><i class="fas fa-poll"></i> คะแนน การรีวิว</a>
    <a href="teacher-profile.php"><i class="fas fa-user"></i> โปรไฟล์</a>
    <a href="?logout=true"><i class="fas fa-sign-out-alt"></i> ออกจากระบบ</a>
</div>


<div class="content">
        <form action="teacher-profile-edit_action.php" method="POST">
        <?php
             // // รับค่า topic_id ที่ส่งมาจาก URL
             $teacher_id = $_GET['teacher_id'];
             $sql = "SELECT * FROM teacher WHERE teacher_id = $teacher_id";
             $result = mysqli_query($conn,$sql);
     
             while ($row=mysqli_fetch_array($result)){
                 $teacher_id = $row['teacher_id'];
                 $email = $row['email'];
                 $username = $row['username'];
                 $password = $row['password'];
                 $fullname = $row['fullname'];
                 $phone = $row['phone']; 
                 $structure = $row['structure']; 
                 $room = $row['room']; 
                 $deleted_id = $row['deleted_id']; 
             }

                    ?>

                    <input type="hidden" id="teacher_id" name="teacher_id" required value="<?php echo $teacher_id; ?>">

                    <label for="email">อีเมลล์ : </label>
                    <input type="text" id="email" name="email" required value="<?php echo $email; ?>"><br><br>

                    <label for="username">ชื่อบัญชีผู้ใช้งาน : </label>
                    <input type="text" id="username" name="username" required value="<?php echo $username; ?>"><br><br>

                    <label for="password">รหัสผ่าน :</label>
                    <input type="password" id="password" name="password" required value="<?php echo $password ?>"><br><br>

                    <label for="fullname">ชื่อ - นามสกุล : </label>
                    <input type="text" id="fullname" name="fullname" required value="<?php echo $fullname ?>"><br><br>

                    <label for="phone">เบอร์โทรศัพท์ : </label>
                    <input type="text" id="phone" name="phone" required value="<?php echo $phone ?>"><br><br>

                    <label for="structure">อาคาร : </label>
                    <select id="structure" name="structure" required value="<?php echo $structure ?>">
                        <option value="1 ชั้น 1 ">1 ชั้น 1 </option>
                        <option value="1 ชั้น 2 ">1 ชั้น 2 </option>
                    </select><br><br>

                    <label for="room">ห้อง : </label>
                    <select id="room" name="room" required>
                        <option value="กิจกรรมพัฒนาผู้เรียน (แนะเเนว) โต๊ะ 1">กิจกรรมพัฒนาผู้เรียน (แนะเเนว) โต๊ะ 1</option>
                        <option value="กิจกรรมพัฒนาผู้เรียน (แนะเเนว) โต๊ะ 2">กิจกรรมพัฒนาผู้เรียน (แนะเเนว) โต๊ะ 2</option>
                        <option value="กิจกรรมพัฒนาผู้เรียน (แนะเเนว) โต๊ะ 3">กิจกรรมพัฒนาผู้เรียน (แนะเเนว) โต๊ะ 3</option>
                        <option value="ห้องปรึกษาปัญหา 1 ">ห้องปรึกษาปัญหา 1 </option>
                        <option value="ห้องปรึกษาปัญหา 1 ">ห้องปรึกษาปัญหา 2 </option>
                    </select><br><br>

                    <label for="profile">รูปภาพโปรไฟล์: </label><br>
                    <input type="file" id="profile" name="profile" accept="image/*"><br><br>

                    <input type="hidden" id="deleted_id" name="deleted_id" required value="<?php echo $deleted_id; ?>">

            <input type="submit" value="บันทึก"> <a href="teacher-profile.php" class="back">ย้อนกลับ</a>
        </form>
    </div>
</body>     
</html>
